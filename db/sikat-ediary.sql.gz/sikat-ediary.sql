-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2024 at 03:36 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sikat-ediary`
--

-- --------------------------------------------------------

--
-- Table structure for table `diary_entries`
--

CREATE TABLE `diary_entries` (
  `entryID` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `userID` int(11) NOT NULL,
  `visibility` enum('private','public') DEFAULT 'private',
  `anonimity` enum('private','public') DEFAULT 'private',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `fileURL` varchar(255) NOT NULL,
  `gadifyCount` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `diary_entries`
--

INSERT INTO `diary_entries` (`entryID`, `title`, `description`, `userID`, `visibility`, `anonimity`, `created_at`, `updated_at`, `fileURL`, `gadifyCount`) VALUES
(32, 'Private', 'Anonymous', 9, 'private', 'private', '2024-09-18 13:52:24', '2024-09-18 17:30:45', '', 1),
(33, 'Public', 'anonymous', 9, 'public', 'private', '2024-09-18 13:52:33', '2024-09-18 15:31:33', '', 1),
(34, 'Try lang din', 'anonymous', 10, 'private', 'private', '2024-09-18 13:53:48', '2024-09-18 15:15:20', '', 1),
(35, 'Public ni kalbo', 'anonymous', 10, 'public', 'private', '2024-09-18 13:54:04', '2024-09-18 18:04:32', '', 1),
(38, 'dasd', 'dasdasdad', 10, 'public', 'public', '2024-09-18 16:23:37', '2024-09-18 18:04:34', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `gadify_actions`
--

CREATE TABLE `gadify_actions` (
  `id` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `entryID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gadify_actions`
--

INSERT INTO `gadify_actions` (`id`, `userID`, `entryID`) VALUES
(43, 9, 32),
(17, 9, 33),
(24, 9, 35),
(40, 9, 38),
(19, 10, 33),
(22, 10, 34),
(44, 10, 35);

-- --------------------------------------------------------

--
-- Table structure for table `user_table`
--

CREATE TABLE `user_table` (
  `userID` int(11) NOT NULL,
  `firstName` varchar(30) NOT NULL,
  `lastName` varchar(30) NOT NULL,
  `cvsuEmail` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_table`
--

INSERT INTO `user_table` (`userID`, `firstName`, `lastName`, `cvsuEmail`, `username`, `password`) VALUES
(9, 'John Victor', 'Silva', 'johnvictor.silva@yahoo.com', 'Jambik', '$2a$10$FJYpoFvke6D8r7psjmfddeD/n2xrPKVT9zrmg31tLlATajddjaNWe'),
(10, 'John Victor', 'Silva', 'johnvictor.silva@yahoo.com', 'Kalbo', '$2a$10$PMWk2SVtBJYBjQloOgqKKufls8C4yx31iwJM9sSDkoWSkBo/er4Vq');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `diary_entries`
--
ALTER TABLE `diary_entries`
  ADD PRIMARY KEY (`entryID`);

--
-- Indexes for table `gadify_actions`
--
ALTER TABLE `gadify_actions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_action` (`userID`,`entryID`),
  ADD KEY `entryID` (`entryID`);

--
-- Indexes for table `user_table`
--
ALTER TABLE `user_table`
  ADD PRIMARY KEY (`userID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `diary_entries`
--
ALTER TABLE `diary_entries`
  MODIFY `entryID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `gadify_actions`
--
ALTER TABLE `gadify_actions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `user_table`
--
ALTER TABLE `user_table`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `gadify_actions`
--
ALTER TABLE `gadify_actions`
  ADD CONSTRAINT `gadify_actions_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `user_table` (`userID`),
  ADD CONSTRAINT `gadify_actions_ibfk_2` FOREIGN KEY (`entryID`) REFERENCES `diary_entries` (`entryID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
