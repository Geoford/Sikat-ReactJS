-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 08, 2024 at 01:56 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sikat-ediary`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `commentID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `entryID` int(11) NOT NULL,
  `text` text NOT NULL,
  `replyCommentID` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`commentID`, `userID`, `entryID`, `text`, `replyCommentID`, `created_at`) VALUES
(7, 29, 12, 'Asd', NULL, '2024-10-03 18:47:47'),
(10, 30, 12, 'Woah', 7, '2024-10-03 18:49:10'),
(11, 29, 12, 'asd', NULL, '2024-10-03 18:55:24'),
(12, 29, 13, 'a', NULL, '2024-10-05 12:30:10'),
(13, 29, 13, 'a', 12, '2024-10-05 12:30:13'),
(14, 29, 13, 'a', 13, '2024-10-05 12:30:17'),
(15, 29, 13, 'a', 13, '2024-10-05 12:30:20'),
(16, 29, 13, 'a', 12, '2024-10-05 12:30:27'),
(17, 29, 13, 'a', 12, '2024-10-05 12:30:33');

-- --------------------------------------------------------

--
-- Table structure for table `diary_entries`
--

CREATE TABLE `diary_entries` (
  `entryID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `visibility` enum('public','private') NOT NULL,
  `anonimity` enum('true','false') NOT NULL DEFAULT 'false',
  `diary_image` varchar(255) DEFAULT NULL,
  `gadifyCount` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `diary_entries`
--

INSERT INTO `diary_entries` (`entryID`, `userID`, `title`, `description`, `visibility`, `anonimity`, `diary_image`, `gadifyCount`, `created_at`) VALUES
(9, 29, 'FOLLOW', 'asd', 'public', '', '', 0, '2024-09-30 17:14:58'),
(10, 31, 'asddasdasd', 'asdsad', 'public', '', '', 1, '2024-09-30 17:32:48'),
(11, 30, 'Woah', 'ASDASDASD', 'public', '', '', 0, '2024-09-30 17:34:04'),
(12, 32, 'Wowers', 'Opo', 'public', '', '/uploads/1727965443235.jpg', 1, '2024-10-03 14:24:03'),
(13, 29, 'ASD', 'asd', 'private', '', '', 1, '2024-10-04 13:53:59');

-- --------------------------------------------------------

--
-- Table structure for table `followers`
--

CREATE TABLE `followers` (
  `userID` int(11) NOT NULL,
  `followedUserID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `followers`
--

INSERT INTO `followers` (`userID`, `followedUserID`) VALUES
(29, 30),
(29, 31),
(29, 32),
(30, 31),
(31, 29),
(31, 30),
(32, 29),
(32, 30),
(32, 31);

-- --------------------------------------------------------

--
-- Table structure for table `gadify_actions`
--

CREATE TABLE `gadify_actions` (
  `gadifyID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `entryID` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `action_taken` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gadify_actions`
--

INSERT INTO `gadify_actions` (`gadifyID`, `userID`, `entryID`, `created_at`, `action_taken`) VALUES
(8, 30, 12, '2024-10-03 14:35:35', NULL),
(19, 29, 13, '2024-10-08 10:16:44', NULL),
(20, 30, 10, '2024-10-08 11:04:59', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `messageID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_profiles`
--

CREATE TABLE `user_profiles` (
  `profileID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `bio` text DEFAULT NULL,
  `alias` varchar(50) DEFAULT NULL,
  `followersCount` int(11) DEFAULT 0,
  `followingCount` int(11) DEFAULT 0,
  `profile_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_profiles`
--

INSERT INTO `user_profiles` (`profileID`, `userID`, `bio`, `alias`, `followersCount`, `followingCount`, `profile_image`) VALUES
(15, 29, 'Hello', 'Secret', 3, 3, '/uploads/1727721817777.jpg'),
(16, 30, NULL, 'asd', 3, 1, '/uploads/1727718033919.png'),
(17, 31, NULL, 'dsa', 3, 3, '/uploads/1727721852196.jpg'),
(18, 32, NULL, 'Allahu', 1, 3, '/uploads/1727964387720.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user_table`
--

CREATE TABLE `user_table` (
  `userID` int(11) NOT NULL,
  `isAdmin` int(10) NOT NULL,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `cvsuEmail` varchar(100) NOT NULL,
  `studentNumber` int(9) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_table`
--

INSERT INTO `user_table` (`userID`, `isAdmin`, `firstName`, `lastName`, `cvsuEmail`, `studentNumber`, `username`, `password`, `created_at`) VALUES
(29, 1, 'John Victor', 'Silva', 'johnvictor.silva@yahoo.com', 202110583, 'Jambik', '$2a$10$GNhK5TgLEA0sR9hlb6uAgOG.HY0.w.r.4bS9Z96dzPoAsHs1FMhyG', '2024-09-30 17:14:36'),
(30, 0, 'John Kenneth', 'Tan', 'johnkenneth.tan@yahoo.com', 1234567890, 'Dave', '$2a$10$YhIZgS.KpDiNV14dF0sPwuynVu/U/ob.jpbQvZMMU.5Ay3mIo6472', '2024-09-30 17:15:28'),
(31, 0, 'John Victoru', 'ASD', 'stephanie@gmail.com', 2147483647, 'Vic', '$2a$10$UCP2K1MtvYhAiHE3qXiNaueL5PCE3IUZjLqwTLVOR/6K5YUH5qoHq', '2024-09-30 17:16:16'),
(32, 0, 'Jem Eraseo Mari', 'Llanto', 'jemmari.llanto@cvsu.edu.ph', 2147483647, 'Jem', '$2a$10$55uYzb8r6HUM6r1zDcKTlOmVIK3pK4pQd4G.S4/jTGX19FYt.tHRG', '2024-10-03 14:03:06');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`commentID`),
  ADD KEY `userID` (`userID`),
  ADD KEY `entryID` (`entryID`),
  ADD KEY `replyCommentID` (`replyCommentID`);

--
-- Indexes for table `diary_entries`
--
ALTER TABLE `diary_entries`
  ADD PRIMARY KEY (`entryID`);

--
-- Indexes for table `followers`
--
ALTER TABLE `followers`
  ADD PRIMARY KEY (`userID`,`followedUserID`),
  ADD KEY `followedUserID` (`followedUserID`);

--
-- Indexes for table `gadify_actions`
--
ALTER TABLE `gadify_actions`
  ADD PRIMARY KEY (`gadifyID`),
  ADD KEY `userID` (`userID`),
  ADD KEY `entryID` (`entryID`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`messageID`),
  ADD KEY `userID` (`userID`);

--
-- Indexes for table `user_profiles`
--
ALTER TABLE `user_profiles`
  ADD PRIMARY KEY (`profileID`),
  ADD KEY `userID` (`userID`);

--
-- Indexes for table `user_table`
--
ALTER TABLE `user_table`
  ADD PRIMARY KEY (`userID`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `commentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `diary_entries`
--
ALTER TABLE `diary_entries`
  MODIFY `entryID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `gadify_actions`
--
ALTER TABLE `gadify_actions`
  MODIFY `gadifyID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `messageID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user_profiles`
--
ALTER TABLE `user_profiles`
  MODIFY `profileID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `user_table`
--
ALTER TABLE `user_table`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `user_table` (`userID`),
  ADD CONSTRAINT `comments_ibfk_2` FOREIGN KEY (`entryID`) REFERENCES `diary_entries` (`entryID`),
  ADD CONSTRAINT `comments_ibfk_3` FOREIGN KEY (`replyCommentID`) REFERENCES `comments` (`commentID`) ON DELETE CASCADE;

--
-- Constraints for table `followers`
--
ALTER TABLE `followers`
  ADD CONSTRAINT `followers_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `user_table` (`userID`),
  ADD CONSTRAINT `followers_ibfk_2` FOREIGN KEY (`followedUserID`) REFERENCES `user_table` (`userID`);

--
-- Constraints for table `gadify_actions`
--
ALTER TABLE `gadify_actions`
  ADD CONSTRAINT `gadify_actions_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `user_table` (`userID`) ON DELETE CASCADE,
  ADD CONSTRAINT `gadify_actions_ibfk_2` FOREIGN KEY (`entryID`) REFERENCES `diary_entries` (`entryID`) ON DELETE CASCADE;

--
-- Constraints for table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `user_table` (`userID`);

--
-- Constraints for table `user_profiles`
--
ALTER TABLE `user_profiles`
  ADD CONSTRAINT `user_profiles_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `user_table` (`userID`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
