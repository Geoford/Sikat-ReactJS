-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 06, 2025 at 04:12 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sikat-ediary`
--

-- --------------------------------------------------------

--
-- Table structure for table `diary_entries`
--

CREATE TABLE `diary_entries` (
  `entryID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `visibility` enum('public','private') NOT NULL,
  `anonimity` enum('private','public') NOT NULL,
  `diary_image` varchar(255) DEFAULT NULL,
  `gadifyCount` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `subjects` text DEFAULT NULL,
  `containsAlarmingWords` tinyint(1) DEFAULT 0,
  `engagementCount` int(11) DEFAULT 0,
  `scheduledDate` datetime DEFAULT NULL,
  `isScheduled` tinyint(1) DEFAULT 0,
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `diary_entries`
--

INSERT INTO `diary_entries` (`entryID`, `userID`, `title`, `description`, `visibility`, `anonimity`, `diary_image`, `gadifyCount`, `created_at`, `subjects`, `containsAlarmingWords`, `engagementCount`, `scheduledDate`, `isScheduled`, `updated_at`) VALUES
(55, 30, 'Domestic', 'Abuse', 'public', 'public', '/uploads/1729670985596.png', 2, '2024-10-23 08:09:45', 'Abuse', 0, 10, NULL, 0, '2025-01-06 15:47:57'),
(57, 31, 'Sexual', 'Harassment', 'public', 'public', '/uploads/1729671217900.gif', 3, '2024-10-23 08:13:38', 'Harrassment', 0, 4, NULL, 0, '2025-01-06 03:54:21'),
(118, 29, '54 Years of Cavite State University - CCAT!', '54 Years of Cavite State University - CCAT!\r\nCelebrate the CvSU Values Center - Truth, Excellence, and Service - as we mark our 54th anniversary! With a theme of \"Pagkakaisa Para sa Patuloy na Pag-Angat ng Sistema ng Kalidad sa Pamamahala ng Edukasyon!\"\r\nJoin us for a special celebration on August 7th and 8th, 2024, with all teachers and staff! Two days of joyful service!\r\nBe part of our first Medical Mission, starting at 8 am on August 7th, 2024, at CvSU-CCAT Covered Court 2. Doctors, nurses, and medical staff from Municipality of Rosario, Rotary Club of CEP, Integrated Philippine Association of Optometrists-Cavite Chapter, JNRAL Family Corporation Hospital, and the CvSU-CCAT Medical Unit will offer free medical and dental services, along with medicines and vitamins.\r\nThis event is open to all teachers, employees, their families, retired staff, concessionaires, midyear students, and registered residents of CvSU-CCAT Road.\r\nCome and take care of your health for a great and brilliant life and service!', 'public', 'public', '/uploads/1731247093740.jpg', 2, '2024-11-10 13:58:13', NULL, 0, 2, NULL, 0, '2025-01-06 11:28:34'),
(119, 29, '𝐀𝐓𝐓𝐄𝐍𝐓𝐈𝐎𝐍 𝐓𝐎 𝐎𝐔𝐑 𝐒𝐓𝐔𝐃𝐄𝐍𝐓 𝐑𝐄𝐒𝐄𝐀𝐑𝐂𝐇𝐄𝐑𝐒!', '𝐀𝐓𝐓𝐄𝐍𝐓𝐈𝐎𝐍 𝐓𝐎 𝐎𝐔𝐑 𝐒𝐓𝐔𝐃𝐄𝐍𝐓 𝐑𝐄𝐒𝐄𝐀𝐑𝐂𝐇𝐄𝐑𝐒!\r\nWe would like to announce this collaborative project of CvSU CCAT - Research and Extension Unit and CvSU - CCAT Gender and Development as part of the celebration of Womens Month this coming March 2024.\r\n𝐆𝐀𝐃 - 𝐑𝐞𝐬𝐩𝐨𝐧𝐬𝐢𝐯𝐞 𝐑𝐞𝐬𝐞𝐚𝐫𝐜𝐡 𝐁𝐨𝐨𝐭𝐜𝐚𝐦𝐩 𝐨𝐧 𝐌𝐚𝐫𝐜𝐡 𝟏𝟐-𝟏𝟒, 𝟐𝟎𝟐𝟒.\r\nSee details below or you may contact your respective unit research coordinators for more information.\r\nPlease be guided accordingly. \r\nWe are looking forward to your participation, see you!', 'public', 'public', '/uploads/1731247143566.jpg', 2, '2024-11-10 13:59:03', NULL, 0, 1, NULL, 0, '2025-01-02 13:39:04'),
(120, 29, 'I AM A WOMAN, OF COURSE.... ', 'I AM A WOMAN, OF COURSE.... \r\nLet\'s talk what it means to be a woman as we begin National Women\'s Month. Let\'s honor Juanas\' amazing strength by breaking stereotypes.', 'public', 'public', '/uploads/1731247209009.jpg', 3, '2024-11-10 14:00:09', NULL, 0, 25, NULL, 0, '2025-01-06 18:22:30'),
(305, 32, 'Dreams Turned Nightmares', 'I used to enjoy dreaming about my future, but now it feels like a nightmare. Every day is a battle, and I don’t know how much longer I can fight.', 'public', 'private', '/uploads/user_diary_images/1736151382589.jpg', 0, '2025-01-06 08:16:22', 'Harassments', 0, 0, NULL, 0, '2025-01-06 16:16:22'),
(306, 32, 'Alone in the Crowd', 'Even when surrounded by people, I feel invisible. I tried to talk to someone today, but they just laughed at me. I feel so alone.', 'public', 'private', '/uploads/user_diary_images/1736151444201.png', 0, '2025-01-06 08:17:24', 'Domestic Violence', 0, 5, NULL, 0, '2025-01-06 18:32:57'),
(307, 32, 'The Fight in the Cafeteria', 'I can’t stop thinking about the mean comments people make about me online. They tell me to hurt myself, and sometimes I feel like they’re right.', 'public', 'public', '/uploads/user_diary_images/1736151507496.png', 0, '2025-01-06 08:18:27', 'Bullying', 0, 0, NULL, 0, '2025-01-06 16:18:27'),
(308, 30, 'The Pressure is Too Much', 'Everyone expects me to do so well in school, but I can’t keep up. Sometimes I feel like the only way out is to quit everything forever.', 'public', 'private', '/uploads/user_diary_images/1736151625077.png', 0, '2025-01-06 08:20:25', 'Domestic Violence', 0, 0, NULL, 0, '2025-01-06 16:20:25'),
(309, 30, 'A Secret I Can’t Share', 'Something bad happened with someone I trusted. I feel ashamed and don’t know who to tell. It’s eating me up inside.', 'public', 'public', '/uploads/user_diary_images/1736151691741.jpg', 0, '2025-01-06 08:21:31', 'Harassments', 0, 2, NULL, 0, '2025-01-06 16:48:09'),
(310, 30, 'The Unspoken Words', 'I heard some classmates talking about me again. They said horrible things. I feel so angry and sad. Sometimes I think of ways to make it all stop.', 'public', 'private', '/uploads/user_diary_images/1736151748348.png', 0, '2025-01-06 08:22:28', 'Harassments', 0, 0, NULL, 0, '2025-01-06 16:22:28'),
(311, 30, 'Feeling Helpless', 'No matter what I do, I can’t make my grades better. My teacher yelled at me in front of everyone today. I feel like a failure and don’t see the point of trying anymore', 'public', 'private', '', 0, '2025-01-06 08:23:00', 'Harassments', 0, 0, NULL, 0, '2025-01-06 16:23:00'),
(312, 53, 'The Incident After Class', 'After class, someone pushed me in the hallway. They said I should just leave the school. I feel so humiliated and scared to come back tomorrow.', 'public', 'private', '/uploads/user_diary_images/1736151925612.jpg', 0, '2025-01-06 08:25:25', 'Domestic Violence', 0, 0, NULL, 0, '2025-01-06 16:25:25'),
(313, 53, 'A Tough Day at School', 'Today felt unbearable. I was bullied again, and they wouldn’t stop calling me names. It makes me feel worthless. Sometimes I wonder if anyone would even notice if I disappeared.', 'public', 'private', '/uploads/user_diary_images/1736151965761.jpg', 0, '2025-01-06 08:26:05', NULL, 0, 0, NULL, 0, '2025-01-06 16:26:05'),
(314, 53, 'A Mistake I Learned From', ' Share a mistake you made and the lesson you learned from it. Reflect on how it changed your behavior or perspective.', 'public', 'private', '/uploads/user_diary_images/1736152016836.jpg', 0, '2025-01-06 08:26:56', NULL, 0, 0, NULL, 0, '2025-01-06 16:26:56'),
(315, 53, 'A School Event I Will Never Forget', 'Narrate an event at school that left a lasting memory, such as a sports day, cultural festival, or debate competition', 'public', 'public', '', 0, '2025-01-06 08:27:35', 'Harassments', 0, 0, NULL, 0, '2025-01-06 16:27:35'),
(318, 54, 'My Favorite Book', 'Write about a book that left a strong impression on you. Discuss the plot, characters, and why it resonated with you.', 'public', 'private', '/uploads/user_diary_images/1736152167335.jpg', 0, '2025-01-06 08:29:27', NULL, 0, 0, NULL, 0, '2025-01-06 16:29:27'),
(319, 54, 'The Day I Helped Someone', 'Reflect on a time you helped someone in need. Write about the situation, how you felt, and how it impacted the other person.', 'public', 'public', '', 0, '2025-01-06 08:29:45', NULL, 0, 0, NULL, 0, '2025-01-06 16:29:45'),
(320, 54, 'My Future Dreams', 'Write about your ambitions and what you aspire to achieve in the future. Discuss your motivation and plans to reach your goals.', 'public', 'private', '/uploads/user_diary_images/1736152222842.jpg', 1, '2025-01-06 08:30:22', NULL, 0, 0, NULL, 0, '2025-01-06 18:33:32'),
(321, 29, 'Legitimo', 'Alla', 'public', 'public', '', 0, '2025-01-06 08:46:46', NULL, 0, 0, '2025-01-07 01:00:00', 1, '2025-01-06 16:46:46'),
(323, 29, 'Legit Check try', 'try test \r\n', 'public', 'public', '', 0, '2025-01-06 10:21:31', NULL, 0, 0, '2025-01-07 02:30:00', 1, '2025-01-06 18:21:31'),
(324, 29, 'try try', 'legit check', 'public', 'public', '', 0, '2025-01-06 10:28:42', NULL, 0, 0, '2025-01-07 02:30:00', 1, '2025-01-06 18:28:42');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `diary_entries`
--
ALTER TABLE `diary_entries`
  ADD PRIMARY KEY (`entryID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `diary_entries`
--
ALTER TABLE `diary_entries`
  MODIFY `entryID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=325;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
