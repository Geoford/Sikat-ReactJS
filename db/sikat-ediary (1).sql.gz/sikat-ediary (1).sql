-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 14, 2024 at 05:08 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sikat-ediary`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `commentID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `entryID` int(11) NOT NULL,
  `text` text NOT NULL,
  `replyCommentID` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`commentID`, `userID`, `entryID`, `text`, `replyCommentID`, `created_at`) VALUES
(25, 32, 110, 'popi', NULL, '2024-11-08 15:39:52'),
(26, 32, 57, 'commenta', NULL, '2024-11-08 15:57:49'),
(27, 31, 57, 'asdasd', NULL, '2024-11-09 12:44:08'),
(30, 32, 159, 'a', NULL, '2024-11-14 14:53:47'),
(32, 32, 159, 'a', NULL, '2024-11-14 15:59:32');

-- --------------------------------------------------------

--
-- Table structure for table `comment_reports`
--

CREATE TABLE `comment_reports` (
  `reportcommentID` int(11) NOT NULL,
  `commentID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `otherText` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comment_reports`
--

INSERT INTO `comment_reports` (`reportcommentID`, `commentID`, `userID`, `reason`, `otherText`, `created_at`) VALUES
(1, 27, 32, 'Bullying', NULL, '2024-11-12 18:24:46');

-- --------------------------------------------------------

--
-- Table structure for table `diary_entries`
--

CREATE TABLE `diary_entries` (
  `entryID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `visibility` enum('public','private') NOT NULL,
  `anonimity` enum('private','public') NOT NULL,
  `diary_image` varchar(255) DEFAULT NULL,
  `gadifyCount` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `subjects` text DEFAULT NULL,
  `containsAlarmingWords` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `diary_entries`
--

INSERT INTO `diary_entries` (`entryID`, `userID`, `title`, `description`, `visibility`, `anonimity`, `diary_image`, `gadifyCount`, `created_at`, `subjects`, `containsAlarmingWords`) VALUES
(55, 30, 'Domestic', 'Abuse', 'public', '', '/uploads/1729670985596.png', 1, '2024-10-23 08:09:45', '\"Domestic Abuse\"', 0),
(57, 31, 'Sexual', 'Harassment', 'public', 'public', '/uploads/1729671217900.gif', 2, '2024-10-23 08:13:38', '\"Sexual Harassment\"', 0),
(118, 29, '54 Years of Cavite State University - CCAT!', '54 Years of Cavite State University - CCAT!\r\nCelebrate the CvSU Values Center - Truth, Excellence, and Service - as we mark our 54th anniversary! With a theme of \"Pagkakaisa Para sa Patuloy na Pag-Angat ng Sistema ng Kalidad sa Pamamahala ng Edukasyon!\"\r\nJoin us for a special celebration on August 7th and 8th, 2024, with all teachers and staff! Two days of joyful service!\r\nBe part of our first Medical Mission, starting at 8 am on August 7th, 2024, at CvSU-CCAT Covered Court 2. Doctors, nurses, and medical staff from Municipality of Rosario, Rotary Club of CEP, Integrated Philippine Association of Optometrists-Cavite Chapter, JNRAL Family Corporation Hospital, and the CvSU-CCAT Medical Unit will offer free medical and dental services, along with medicines and vitamins.\r\nThis event is open to all teachers, employees, their families, retired staff, concessionaires, midyear students, and registered residents of CvSU-CCAT Road.\r\nCome and take care of your health for a great and brilliant life and service!', 'public', 'public', '/uploads/1731247093740.jpg', 0, '2024-11-10 13:58:13', NULL, 0),
(119, 29, '𝐀𝐓𝐓𝐄𝐍𝐓𝐈𝐎𝐍 𝐓𝐎 𝐎𝐔𝐑 𝐒𝐓𝐔𝐃𝐄𝐍𝐓 𝐑𝐄𝐒𝐄𝐀𝐑𝐂𝐇𝐄𝐑𝐒!', '𝐀𝐓𝐓𝐄𝐍𝐓𝐈𝐎𝐍 𝐓𝐎 𝐎𝐔𝐑 𝐒𝐓𝐔𝐃𝐄𝐍𝐓 𝐑𝐄𝐒𝐄𝐀𝐑𝐂𝐇𝐄𝐑𝐒!\r\nWe would like to announce this collaborative project of CvSU CCAT - Research and Extension Unit and CvSU - CCAT Gender and Development as part of the celebration of Womens Month this coming March 2024.\r\n𝐆𝐀𝐃 - 𝐑𝐞𝐬𝐩𝐨𝐧𝐬𝐢𝐯𝐞 𝐑𝐞𝐬𝐞𝐚𝐫𝐜𝐡 𝐁𝐨𝐨𝐭𝐜𝐚𝐦𝐩 𝐨𝐧 𝐌𝐚𝐫𝐜𝐡 𝟏𝟐-𝟏𝟒, 𝟐𝟎𝟐𝟒.\r\nSee details below or you may contact your respective unit research coordinators for more information.\r\nPlease be guided accordingly. \r\nWe are looking forward to your participation, see you!', 'public', 'public', '/uploads/1731247143566.jpg', 0, '2024-11-10 13:59:03', NULL, 0),
(120, 29, 'I AM A WOMAN, OF COURSE.... ', 'I AM A WOMAN, OF COURSE.... \r\nLet\'s talk what it means to be a woman as we begin National Women\'s Month. Let\'s honor Juanas\' amazing strength by breaking stereotypes.', 'public', 'public', '/uploads/1731247209009.jpg', 0, '2024-11-10 14:00:09', NULL, 0),
(159, 32, 'asdasd', 'asdasd', 'private', 'private', '', 0, '2024-11-14 14:33:00', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `filter_subjects`
--

CREATE TABLE `filter_subjects` (
  `subjectID` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `filter_subjects`
--

INSERT INTO `filter_subjects` (`subjectID`, `subject`) VALUES
(7, 'Harassment'),
(8, 'Abuse'),
(9, 'Bullying');

-- --------------------------------------------------------

--
-- Table structure for table `flagged_reports`
--

CREATE TABLE `flagged_reports` (
  `report_id` int(20) NOT NULL,
  `behaviors` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `other_text` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `userID` int(11) NOT NULL,
  `entryID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `flagging_options`
--

CREATE TABLE `flagging_options` (
  `flagID` int(11) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `count` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `flagging_options`
--

INSERT INTO `flagging_options` (`flagID`, `reason`, `count`) VALUES
(3, 'Harassment', 0),
(9, 'Bullying', 0),
(10, 'Abuse', 0),
(11, 'Harmful', 0),
(12, 'Inappropriate', 0);

-- --------------------------------------------------------

--
-- Table structure for table `followers`
--

CREATE TABLE `followers` (
  `userID` int(11) NOT NULL,
  `followedUserID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `followers`
--

INSERT INTO `followers` (`userID`, `followedUserID`) VALUES
(30, 31),
(30, 32),
(32, 29),
(32, 30);

-- --------------------------------------------------------

--
-- Table structure for table `gadify_actions`
--

CREATE TABLE `gadify_actions` (
  `gadifyID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `entryID` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `action_taken` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gadify_actions`
--

INSERT INTO `gadify_actions` (`gadifyID`, `userID`, `entryID`, `created_at`, `action_taken`) VALUES
(58, 32, 55, '2024-10-23 08:09:59', NULL),
(77, 31, 57, '2024-10-31 08:54:52', NULL),
(109, 32, 57, '2024-11-08 16:14:34', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `gender_based_crime_reports`
--

CREATE TABLE `gender_based_crime_reports` (
  `reportID` int(11) NOT NULL,
  `victimName` varchar(255) NOT NULL,
  `perpetratorName` varchar(255) NOT NULL,
  `contactInfo` varchar(255) NOT NULL,
  `gender` enum('male','female','non-binary','prefer-not-to-say') NOT NULL,
  `incidentDescription` text NOT NULL,
  `location` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `supportingDocuments` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `subjects` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gender_based_crime_reports`
--

INSERT INTO `gender_based_crime_reports` (`reportID`, `victimName`, `perpetratorName`, `contactInfo`, `gender`, `incidentDescription`, `location`, `date`, `supportingDocuments`, `created_at`, `subjects`) VALUES
(10, 'asd', 'asd', 'asd', 'male', 'asd', 'asd', '2024-11-28', NULL, '2024-11-14 15:03:36', NULL),
(11, 'asd', 'asd', 'asd', 'male', 'asd', 'asd', '2024-11-21', '1731596755309.png', '2024-11-14 15:05:55', NULL),
(12, 'a', 'a', 'a', 'male', 'a', 'a', '2024-11-30', NULL, '2024-11-14 15:28:53', NULL),
(13, 'a', 'a', 'a', 'male', 'aa', 'a', '2024-11-13', NULL, '2024-11-14 15:30:43', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `messageID` int(11) NOT NULL,
  `senderID` int(11) NOT NULL,
  `recipientID` int(11) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `isAdmin` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `notificationID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `actorID` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `entryID` int(11) DEFAULT NULL,
  `type` enum('gadify','follow','unfollow','comment') NOT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `profile_image` varchar(255) NOT NULL,
  `read` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`notificationID`, `userID`, `actorID`, `message`, `entryID`, `type`, `timestamp`, `profile_image`, `read`) VALUES
(116, 31, 32, 'Jem gadified your diary entry.', 57, 'gadify', '2024-11-09 00:11:33', '/uploads/1730098104830.jpg', 0),
(117, 31, 32, 'Jem gadified your diary entry.', 57, 'gadify', '2024-11-09 00:12:23', '/uploads/1730098104830.jpg', 0),
(118, 31, 32, 'Jem gadified your diary entry.', 57, 'gadify', '2024-11-09 00:13:11', '/uploads/1730098104830.jpg', 0),
(119, 31, 32, 'Jem gadified your diary entry.', 57, 'gadify', '2024-11-09 00:13:18', '/uploads/1730098104830.jpg', 0),
(120, 31, 32, 'Jem gadified your diary entry.', 57, 'gadify', '2024-11-09 00:14:34', '/uploads/1730098104830.jpg', 0),
(121, 32, 29, 'Jambik gadified your diary entry.', 112, 'gadify', '2024-11-13 00:38:24', '/uploads/1731247253324.jpg', 0),
(122, 31, 32, 'Jem commented on your diary entry.', 57, 'comment', '2024-11-14 22:19:20', '/uploads/1730098104830.jpg', 0),
(123, 31, 32, 'Jem commented on your diary entry.', 57, 'comment', '2024-11-14 22:33:10', '/uploads/1730098104830.jpg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `reporting_users`
--

CREATE TABLE `reporting_users` (
  `reportingUserID` int(11) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `count` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reporting_users`
--

INSERT INTO `reporting_users` (`reportingUserID`, `reason`, `count`) VALUES
(3, 'Harmful', 0);

-- --------------------------------------------------------

--
-- Table structure for table `report_comments`
--

CREATE TABLE `report_comments` (
  `reportCommentID` int(11) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `count` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `report_comments`
--

INSERT INTO `report_comments` (`reportCommentID`, `reason`, `count`) VALUES
(4, 'Bullying', 0),
(5, 'Violent', 0),
(6, 'Harmful', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_profiles`
--

CREATE TABLE `user_profiles` (
  `profileID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `bio` text DEFAULT NULL,
  `alias` varchar(50) DEFAULT NULL,
  `followersCount` int(11) DEFAULT 0,
  `followingCount` int(11) DEFAULT 0,
  `profile_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_profiles`
--

INSERT INTO `user_profiles` (`profileID`, `userID`, `bio`, `alias`, `followersCount`, `followingCount`, `profile_image`) VALUES
(15, 29, 'Don\'t be afraid we  are here to HELP YOU! ', 'Admin', 3, 0, '/uploads/1731247253324.jpg'),
(16, 30, 'Alla', 'asd', 1, 3, '/uploads/1727718033919.png'),
(17, 31, NULL, 'dsa', 4, 0, '/uploads/1729678765054.jpg'),
(18, 32, 'bat ka andito?', 'Allahu', 2, 2, '/uploads/1730098104830.jpg'),
(28, 46, NULL, 'Jem', 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `user_table`
--

CREATE TABLE `user_table` (
  `userID` int(11) NOT NULL,
  `isAdmin` int(10) NOT NULL,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `cvsuEmail` varchar(100) NOT NULL,
  `studentNumber` int(9) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `verificationToken` varchar(255) DEFAULT NULL,
  `isVerified` tinyint(1) DEFAULT 0,
  `login_attempts` int(11) DEFAULT 0,
  `is_locked` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_table`
--

INSERT INTO `user_table` (`userID`, `isAdmin`, `firstName`, `lastName`, `cvsuEmail`, `studentNumber`, `username`, `password`, `created_at`, `verificationToken`, `isVerified`, `login_attempts`, `is_locked`) VALUES
(29, 1, 'Gender and Development', '- GAD', 'johnvictor.silva@yahoo.com', 202110583, 'Jambik', '$2a$10$GNhK5TgLEA0sR9hlb6uAgOG.HY0.w.r.4bS9Z96dzPoAsHs1FMhyG', '2024-09-30 17:14:36', NULL, 0, 0, 0),
(30, 0, 'John Kenneth', 'Tan', 'johnkenneth.tan@yahoo.com', 1234567890, 'Dave', '$2a$10$YhIZgS.KpDiNV14dF0sPwuynVu/U/ob.jpbQvZMMU.5Ay3mIo6472', '2024-09-30 17:15:28', NULL, 0, 0, 0),
(31, 0, 'John Victoru', 'ASD', 'allahu@gmail.com', 2147483647, 'Vic', '$2a$10$UCP2K1MtvYhAiHE3qXiNaueL5PCE3IUZjLqwTLVOR/6K5YUH5qoHq', '2024-09-30 17:16:16', NULL, 0, 0, 0),
(32, 0, 'Jem', 'Llanto', 'jemmari.llanto@cvsu.edu.ph', 2147483647, 'Jem', '$2a$10$55uYzb8r6HUM6r1zDcKTlOmVIK3pK4pQd4G.S4/jTGX19FYt.tHRG', '2024-10-03 14:03:06', NULL, 0, 0, 0),
(46, 0, 'Jan Eraseo Mari', 'Llanto', 'janeraseomari.llanto@cvsu.edu.ph', 202010933, 'JemLlanto', '$2a$10$wmwbGH6HN5s8J1QfGyCG4uuQzXztqRd7xRuuMxReRh4OO4GHQYD7e', '2024-11-10 13:55:46', 'ea7369d4e995265342a5ff54845d377a3874dfb9', 1, 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`commentID`);

--
-- Indexes for table `comment_reports`
--
ALTER TABLE `comment_reports`
  ADD PRIMARY KEY (`reportcommentID`),
  ADD KEY `commentID` (`commentID`),
  ADD KEY `userID` (`userID`);

--
-- Indexes for table `diary_entries`
--
ALTER TABLE `diary_entries`
  ADD PRIMARY KEY (`entryID`);

--
-- Indexes for table `filter_subjects`
--
ALTER TABLE `filter_subjects`
  ADD PRIMARY KEY (`subjectID`);

--
-- Indexes for table `flagged_reports`
--
ALTER TABLE `flagged_reports`
  ADD PRIMARY KEY (`report_id`);

--
-- Indexes for table `flagging_options`
--
ALTER TABLE `flagging_options`
  ADD PRIMARY KEY (`flagID`);

--
-- Indexes for table `followers`
--
ALTER TABLE `followers`
  ADD PRIMARY KEY (`userID`,`followedUserID`),
  ADD KEY `followedUserID` (`followedUserID`);

--
-- Indexes for table `gadify_actions`
--
ALTER TABLE `gadify_actions`
  ADD PRIMARY KEY (`gadifyID`),
  ADD KEY `userID` (`userID`),
  ADD KEY `entryID` (`entryID`);

--
-- Indexes for table `gender_based_crime_reports`
--
ALTER TABLE `gender_based_crime_reports`
  ADD PRIMARY KEY (`reportID`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`messageID`),
  ADD KEY `senderID` (`senderID`),
  ADD KEY `recipientID` (`recipientID`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`notificationID`),
  ADD KEY `userID` (`userID`),
  ADD KEY `actorID` (`actorID`);

--
-- Indexes for table `reporting_users`
--
ALTER TABLE `reporting_users`
  ADD PRIMARY KEY (`reportingUserID`);

--
-- Indexes for table `report_comments`
--
ALTER TABLE `report_comments`
  ADD PRIMARY KEY (`reportCommentID`);

--
-- Indexes for table `user_profiles`
--
ALTER TABLE `user_profiles`
  ADD PRIMARY KEY (`profileID`),
  ADD KEY `userID` (`userID`);

--
-- Indexes for table `user_table`
--
ALTER TABLE `user_table`
  ADD PRIMARY KEY (`userID`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `commentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `comment_reports`
--
ALTER TABLE `comment_reports`
  MODIFY `reportcommentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `diary_entries`
--
ALTER TABLE `diary_entries`
  MODIFY `entryID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=160;

--
-- AUTO_INCREMENT for table `filter_subjects`
--
ALTER TABLE `filter_subjects`
  MODIFY `subjectID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `flagged_reports`
--
ALTER TABLE `flagged_reports`
  MODIFY `report_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `flagging_options`
--
ALTER TABLE `flagging_options`
  MODIFY `flagID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `gadify_actions`
--
ALTER TABLE `gadify_actions`
  MODIFY `gadifyID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=112;

--
-- AUTO_INCREMENT for table `gender_based_crime_reports`
--
ALTER TABLE `gender_based_crime_reports`
  MODIFY `reportID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `messageID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=120;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `notificationID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=124;

--
-- AUTO_INCREMENT for table `reporting_users`
--
ALTER TABLE `reporting_users`
  MODIFY `reportingUserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `report_comments`
--
ALTER TABLE `report_comments`
  MODIFY `reportCommentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `user_profiles`
--
ALTER TABLE `user_profiles`
  MODIFY `profileID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `user_table`
--
ALTER TABLE `user_table`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comment_reports`
--
ALTER TABLE `comment_reports`
  ADD CONSTRAINT `comment_reports_ibfk_1` FOREIGN KEY (`commentID`) REFERENCES `comments` (`commentID`),
  ADD CONSTRAINT `comment_reports_ibfk_2` FOREIGN KEY (`userID`) REFERENCES `user_table` (`userID`);

--
-- Constraints for table `followers`
--
ALTER TABLE `followers`
  ADD CONSTRAINT `followers_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `user_table` (`userID`),
  ADD CONSTRAINT `followers_ibfk_2` FOREIGN KEY (`followedUserID`) REFERENCES `user_table` (`userID`);

--
-- Constraints for table `gadify_actions`
--
ALTER TABLE `gadify_actions`
  ADD CONSTRAINT `gadify_actions_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `user_table` (`userID`) ON DELETE CASCADE,
  ADD CONSTRAINT `gadify_actions_ibfk_2` FOREIGN KEY (`entryID`) REFERENCES `diary_entries` (`entryID`) ON DELETE CASCADE;

--
-- Constraints for table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`senderID`) REFERENCES `user_table` (`userID`),
  ADD CONSTRAINT `messages_ibfk_2` FOREIGN KEY (`recipientID`) REFERENCES `user_table` (`userID`);

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `user_table` (`userID`),
  ADD CONSTRAINT `notifications_ibfk_2` FOREIGN KEY (`actorID`) REFERENCES `user_table` (`userID`);

--
-- Constraints for table `user_profiles`
--
ALTER TABLE `user_profiles`
  ADD CONSTRAINT `user_profiles_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `user_table` (`userID`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
