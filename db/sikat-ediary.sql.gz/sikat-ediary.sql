-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 28, 2025 at 11:50 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sikat-ediary`
--

-- --------------------------------------------------------

--
-- Table structure for table `alarming_words`
--

CREATE TABLE `alarming_words` (
  `wordID` int(11) NOT NULL,
  `alarmingWord` varchar(255) NOT NULL,
  `count` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `alarming_words`
--

INSERT INTO `alarming_words` (`wordID`, `alarmingWord`, `count`) VALUES
(1, 'murdered', 0),
(2, 'suicide', 0),
(3, 'murder', 0),
(4, 'death', 0),
(5, 'violence', 0),
(6, 'threat', 0),
(7, 'danger', 0),
(8, 'bullying', 0),
(9, 'assault', 0),
(10, 'self-harm', 0),
(11, 'exploitation', 0),
(12, 'kidnapping', 0),
(13, 'terrorism', 0),
(14, 'corruption', 0),
(15, 'abduction', 0),
(16, 'stalking', 0),
(17, 'drugs', 0),
(18, 'addiction', 0),
(19, 'mental illness', 0),
(20, 'torture', 0),
(21, 'rape culture', 0),
(22, 'cyberbullying', 0),
(23, 'bully', 0),
(24, 'sinasaktan', 0),
(26, 'help', 0),
(27, 'patay', 0),
(28, 'masakit', 0),
(29, 'kaya', 0),
(30, 'Masakit', 0);

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `commentID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `entryID` int(11) NOT NULL,
  `text` text NOT NULL,
  `repliedUserID` int(11) DEFAULT NULL,
  `replyCommentID` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`commentID`, `userID`, `entryID`, `text`, `repliedUserID`, `replyCommentID`, `created_at`) VALUES
(118, 58, 435, 'I remember a time when a colleague felt hesitant to share their ideas during a meeting, fearing they wouldn\'t be taken seriously. I encouraged them to speak up and assured them that their insights were valuable. Their contribution ended up reshaping our project for the better and inspired others to share more openly as well.\"', NULL, NULL, '2025-01-14 07:00:47'),
(119, 65, 437, 'During a team project at work, I noticed a communication gap between male and female colleagues. The women in the group often hesitated to voice their ideas during meetings, while the men tended to dominate discussions. This imbalance led to frustration on both sides, as some team members felt unheard while others were unaware of the issue.\n\nTo address this, I initiated an open dialogue with the team, highlighting the importance of diverse perspectives. I encouraged everyone to share their views on how we could create a more inclusive environment. Together, we implemented small but meaningful changes, such as a structured roundtable format where everyone had equal opportunities to speak.\n\nOver time, the team dynamics improved. We saw better collaboration, more innovative solutions, and a deeper sense of mutual respect. It was rewarding to see how understanding and intentional changes could bridge the gap and create a truly collaborative environment.', NULL, NULL, '2025-01-14 07:26:37'),
(120, 30, 443, 'There’s something magical about shared laughter. Today, someone cracked a joke in class—it must have been hilarious because we all laughed so hard that the teacher had to step in and tell us to stop. Honestly, I don’t even remember the joke now, but the feeling of that moment stuck with me.\n\nIt wasn’t just the joke; it was the way laughter brought us all together, even for a brief moment. It made the classroom feel lighter, more connected. Sometimes, it’s not the words but the shared joy that lingers the longest.', NULL, NULL, '2025-01-14 07:36:47'),
(121, 67, 386, 'I used to find so much joy in dreaming about my future—imagining the possibilities, the adventures, and the successes that lay ahead. But lately, those dreams have turned into something darker, more like nightmares.\n\nEach day feels like an uphill battle, and the weight of it all is exhausting. The hope that once fueled me now feels distant, and I find myself wondering how much longer I can keep fighting.\n\nBut even in this darkness, I remind myself that tough times don’t last forever. It’s okay to feel lost, to pause, and to take things one step at a time. Maybe, just maybe, the light will find its way back into my dreams.', NULL, NULL, '2025-01-14 07:46:59'),
(122, 32, 120, 'Women empowerment', NULL, NULL, '2025-01-14 11:50:45'),
(137, 54, 386, 'Hello', NULL, NULL, '2025-01-14 12:26:48'),
(159, 32, 435, 'Hello po', 58, 118, '2025-01-27 22:46:36'),
(160, 29, 437, 'Wag kang susuko kaya moyan!!!', NULL, NULL, '2025-01-27 23:59:44'),
(161, 29, 435, 'Please be mindful for your words', 32, 159, '2025-01-28 02:08:23'),
(162, 79, 434, 'Hello', NULL, NULL, '2025-01-28 05:23:46');

-- --------------------------------------------------------

--
-- Table structure for table `comment_reports`
--

CREATE TABLE `comment_reports` (
  `reportcommentID` int(11) NOT NULL,
  `commentID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `entryID` int(11) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `otherText` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `isAddress` tinyint(1) DEFAULT 0,
  `isReviewed` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comment_reports`
--

INSERT INTO `comment_reports` (`reportcommentID`, `commentID`, `userID`, `entryID`, `reason`, `otherText`, `created_at`, `isAddress`, `isReviewed`) VALUES
(5, 26, 32, 57, 'Bullying', NULL, '2024-11-20 15:51:40', 1, 0),
(6, 34, 29, 57, 'Bullying', NULL, '2024-11-25 17:40:07', 1, 0),
(9, 34, 29, 57, 'Harmful', NULL, '2024-11-25 18:00:46', 1, 0),
(10, 41, 54, 213, 'Violent', NULL, '2024-12-26 14:32:26', 0, 0),
(11, 43, 32, 119, 'Insensitive Comment', NULL, '2025-01-07 13:35:24', 1, 0),
(12, 43, 32, 119, 'Sample reporting comments', NULL, '2025-01-07 13:40:54', 1, 0),
(13, 94, 67, 406, 'Violent', NULL, '2025-01-10 07:45:57', 1, 0),
(14, 96, 68, 391, 'Bullying', NULL, '2025-01-10 15:29:06', 1, 0),
(15, 95, 68, 383, 'Hate Speech', NULL, '2025-01-10 15:49:36', 1, 0),
(16, 96, 68, 391, 'Violent', NULL, '2025-01-10 16:16:12', 1, 0),
(17, 96, 68, 391, 'Violent', NULL, '2025-01-10 16:17:08', 1, 0),
(18, 96, 68, 391, 'Insensitive Comment', NULL, '2025-01-10 16:19:25', 1, 0),
(19, 96, 68, 391, 'Insensitive Comment', NULL, '2025-01-10 16:19:52', 1, 0),
(20, 96, 68, 391, 'Violent', NULL, '2025-01-10 16:21:05', 1, 0),
(21, 96, 68, 391, 'Bullying', NULL, '2025-01-10 16:21:32', 1, 0),
(22, 96, 68, 391, 'Bullying', NULL, '2025-01-10 16:22:07', 0, 0),
(23, 95, 68, 383, 'Violent', NULL, '2025-01-10 16:30:16', 0, 0),
(24, 95, 68, 383, 'Bullying', NULL, '2025-01-10 16:30:51', 0, 0),
(25, 95, 68, 383, 'Insensitive Comment', NULL, '2025-01-10 16:31:36', 0, 0),
(26, 95, 68, 383, 'Bullying', NULL, '2025-01-10 16:31:50', 0, 0),
(27, 95, 68, 383, 'Bullying', NULL, '2025-01-10 16:32:10', 0, 0),
(28, 95, 68, 383, 'Violent', NULL, '2025-01-10 16:32:33', 0, 0),
(29, 95, 68, 383, 'Bullying', NULL, '2025-01-10 16:32:57', 0, 0),
(30, 95, 68, 383, 'Bullying', NULL, '2025-01-10 16:33:11', 0, 0),
(31, 96, 68, 391, 'Hate Speech', NULL, '2025-01-11 01:53:59', 0, 0),
(32, 96, 68, 391, 'Violent', NULL, '2025-01-11 04:16:27', 0, 0),
(33, 96, 68, 391, 'Bullying', NULL, '2025-01-11 07:53:55', 0, 0),
(34, 96, 68, 391, 'Violent', NULL, '2025-01-12 03:09:10', 0, 0),
(35, 96, 68, 391, 'Violent', NULL, '2025-01-12 03:37:06', 0, 0),
(36, 27, 31, 57, 'Bullying', NULL, '2025-01-12 03:37:50', 0, 0),
(37, 96, 68, 391, 'Violent', NULL, '2025-01-12 03:38:12', 0, 0),
(38, 96, 68, 391, 'Bullying', NULL, '2025-01-12 03:38:30', 0, 0),
(39, 33, 31, 55, 'Violent', NULL, '2025-01-13 12:35:47', 0, 1),
(40, 78, 58, 119, 'Others', NULL, '2025-01-14 00:43:35', 0, 0),
(41, 118, 58, 435, 'Hate Speech', NULL, '2025-01-14 07:34:36', 1, 0),
(42, 118, 58, 435, 'Hate Speech', NULL, '2025-01-14 07:34:45', 1, 0),
(43, 120, 30, 443, 'Violent', NULL, '2025-01-14 07:45:15', 1, 0),
(44, 121, 67, 386, 'Others', 'dead', '2025-01-14 12:27:03', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `diary_entries`
--

CREATE TABLE `diary_entries` (
  `entryID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `visibility` enum('public','private') NOT NULL,
  `anonimity` enum('private','public') NOT NULL,
  `diary_image` varchar(255) DEFAULT NULL,
  `gadifyCount` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `subjects` text DEFAULT NULL,
  `containsAlarmingWords` tinyint(1) DEFAULT 0,
  `isFlagged` tinyint(1) DEFAULT 0,
  `isHide` tinyint(1) NOT NULL DEFAULT 0,
  `engagementCount` int(11) DEFAULT 0,
  `scheduledDate` datetime DEFAULT NULL,
  `isScheduled` tinyint(1) DEFAULT 0,
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `diary_entries`
--

INSERT INTO `diary_entries` (`entryID`, `userID`, `title`, `description`, `visibility`, `anonimity`, `diary_image`, `gadifyCount`, `created_at`, `subjects`, `containsAlarmingWords`, `isFlagged`, `isHide`, `engagementCount`, `scheduledDate`, `isScheduled`, `updated_at`) VALUES
(118, 29, '54 Years of Cavite State University - CCAT!', '54 Years of Cavite State University - CCAT!\r\nCelebrate the CvSU Values Center - Truth, Excellence, and Service - as we mark our 54th anniversary! With a theme of \"Pagkakaisa Para sa Patuloy na Pag-Angat ng Sistema ng Kalidad sa Pamamahala ng Edukasyon!\"\r\nJoin us for a special celebration on August 7th and 8th, 2024, with all teachers and staff! Two days of joyful service!\r\nBe part of our first Medical Mission, starting at 8 am on August 7th, 2024, at CvSU-CCAT Covered Court 2. Doctors, nurses, and medical staff from Municipality of Rosario, Rotary Club of CEP, Integrated Philippine Association of Optometrists-Cavite Chapter, JNRAL Family Corporation Hospital, and the CvSU-CCAT Medical Unit will offer free medical and dental services, along with medicines and vitamins.\r\nThis event is open to all teachers, employees, their families, retired staff, concessionaires, midyear students, and registered residents of CvSU-CCAT Road.\r\nCome and take care of your health for a great and brilliant life and service!', 'public', 'public', '/uploads/1731247093740.jpg', 2, '2024-11-10 13:58:13', NULL, 0, 0, 0, 2, NULL, 0, '2025-01-06 11:28:34'),
(119, 29, '𝐀𝐓𝐓𝐄𝐍𝐓𝐈𝐎𝐍 𝐓𝐎 𝐎𝐔𝐑 𝐒𝐓𝐔𝐃𝐄𝐍𝐓 𝐑𝐄𝐒𝐄𝐀𝐑𝐂𝐇𝐄𝐑𝐒', '𝐀𝐓𝐓𝐄𝐍𝐓𝐈𝐎𝐍 𝐓𝐎 𝐎𝐔𝐑 𝐒𝐓𝐔𝐃𝐄𝐍𝐓 𝐑𝐄𝐒𝐄𝐀𝐑𝐂𝐇𝐄𝐑𝐒!\r\nWe would like to announce this collaborative project of CvSU CCAT - Research and Extension Unit and CvSU - CCAT Gender and Development as part of the celebration of Womens Month this coming March 2024.\r\n𝐆𝐀𝐃 - 𝐑𝐞𝐬𝐩𝐨𝐧𝐬𝐢𝐯𝐞 𝐑𝐞𝐬𝐞𝐚𝐫𝐜𝐡 𝐁𝐨𝐨𝐭𝐜𝐚𝐦𝐩 𝐨𝐧 𝐌𝐚𝐫𝐜𝐡 𝟏𝟐-𝟏𝟒, 𝟐𝟎𝟐𝟒.\r\nSee details below or you may contact your respective unit research coordinators for more information.\r\nPlease be guided accordingly. \r\nWe are looking forward to your participation, see you!', 'public', 'public', '/uploads/1731247143566.jpg', 3, '2024-11-10 13:59:03', NULL, 0, 0, 0, 11, NULL, 0, '2025-01-14 20:18:15'),
(120, 29, 'I AM A WOMAN, OF COURSE', 'I AM A WOMAN, OF COURSE.... \r\nLet\'s talk what it means to be a woman as we begin National Women\'s Month. Let\'s honor Juanas\' amazing strength by breaking stereotypes.', 'public', 'public', '/uploads/1731247209009.jpg', 4, '2024-11-10 14:00:09', NULL, 0, 0, 0, 62, NULL, 0, '2025-01-28 11:27:05'),
(308, 30, 'The Pressure is Too Much', 'Everyone expects me to do so well in school, but I can’t keep up. Sometimes I feel like the only way out is to quit everything forever.', 'private', 'private', '/uploads/user_diary_images/1736151625077.png', 2, '2025-01-06 08:20:25', 'Domestic Violence', 0, 0, 1, 15, NULL, 0, '2025-01-14 02:10:39'),
(311, 30, 'Feeling Helpless', 'No matter what I do, I can’t make my grades better. My teacher yelled at me in front of everyone today. I feel like a failure and don’t see the point of trying anymore', 'public', 'private', '', 0, '2025-01-06 08:23:00', 'Cyberstalking and Online Harassment', 0, 0, 1, 5, NULL, 0, '2025-01-22 09:28:20'),
(315, 53, 'A School Event I Will Never Forget', 'Narrate an event at school that left a lasting memory, such as a sports day, cultural festival, or debate competition', 'public', 'public', '', 1, '2025-01-06 08:27:35', 'Cyberstalking and Online Harassment', 0, 1, 0, 2, NULL, 0, '2025-01-28 13:24:25'),
(319, 54, 'The Day I Helped Someone', 'Reflect on a time you helped someone in need. Write about the situation, how you felt, and how it impacted the other person.', 'public', 'public', '', 1, '2025-01-06 08:29:45', 'General', 0, 0, 0, 0, NULL, 0, '2025-01-28 06:22:45'),
(382, 54, 'The Day I Helped Someone', 'Reflect on a time you helped someone in need. Write about the situation, how you felt, and how it impacted the other person.', 'public', 'public', '/uploads/user_diary_images/1736405455638.jpg', 0, '2025-01-09 06:50:55', 'Cyberstalking and Online Harassment', 0, 1, 0, 8, NULL, 0, '2025-01-27 20:00:55'),
(383, 54, 'My Favorite Book', 'Write about a book that left a strong impression on you. Discuss the plot, characters, and why it resonated with you.', 'private', 'private', '/uploads/user_diary_images/1736405667548.jpg', 1, '2025-01-09 06:54:27', 'Domestic Violence', 0, 1, 1, 6, NULL, 0, '2025-01-14 13:52:05'),
(384, 32, 'The Fight in the Cafeteria', 'I can’t stop thinking about the mean comments people make about me online. They tell me to hurt myself, and sometimes I feel like they’re right.', 'public', 'private', '/uploads/user_diary_images/1736405940840.jpg', 0, '2025-01-09 06:59:00', 'Domestic Violence', 0, 1, 0, 27, NULL, 0, '2025-01-22 09:28:57'),
(385, 32, 'Alone in the Crowdss', 'Even when surrounded by people, I feel invisible. I tried to talk to someone today, but they just laughed at me. I feel so alone.', 'private', 'private', NULL, 0, '2025-01-09 06:59:25', 'General', 0, 0, 0, 1, NULL, 0, '2025-01-22 09:27:44'),
(386, 32, 'Dreams Turned Nightmare', 'I used to enjoy dreaming about my future, but now it feels like a nightmare. Every day is a battle, and I don’t know how much longer I can fight.', 'public', 'public', NULL, 4, '2025-01-09 07:00:11', 'General', 0, 1, 0, 61, NULL, 0, '2025-01-22 09:27:41'),
(387, 53, 'A Mistake I Learned From', ' Share a mistake you made and the lesson you learned from it. Reflect on how it changed your behavior or perspective.', 'public', 'private', '/uploads/user_diary_images/1736406236924.jpg', 1, '2025-01-09 07:03:56', 'General', 0, 1, 0, 2, NULL, 0, '2025-01-28 07:55:18'),
(388, 53, 'A Tough Day at School', 'Today felt unbearable. I was bullied again, and they wouldn’t stop calling me names. It makes me feel worthless. Sometimes I wonder if anyone would even notice if I disappeared.', 'private', 'private', '/uploads/user_diary_images/1736406280114.jpg', 1, '2025-01-09 07:04:40', 'Cyberbullying', 0, 0, 1, 2, NULL, 0, '2025-01-22 09:29:41'),
(389, 53, 'The Incident After Class', 'After class, someone pushed me in the hallway. They said I should just leave the school. I feel so humiliated and scared to come back tomorrow.', 'public', 'public', '/uploads/user_diary_images/1736406316272.jpg', 1, '2025-01-09 07:05:16', 'General', 0, 1, 0, 4, NULL, 0, '2025-01-22 09:27:36'),
(434, 57, 'Breaking Barriers', 'Write about a time you challenged a gender stereotype. How did it feel, and what was the reaction of those around you?', 'public', 'public', '/uploads/user_diary_images/1736837202257.png', 2, '2025-01-14 06:46:42', 'General', 0, 0, 0, 2, NULL, 0, '2025-01-28 13:23:46'),
(435, 57, 'Empowering Voices', 'Reflect on an instance where you supported someone to speak up or share their story, particularly regarding gender equality.', 'public', 'private', '', 2, '2025-01-14 06:47:56', 'General', 0, 0, 0, 8, NULL, 0, '2025-01-28 10:08:23'),
(436, 58, 'The Power of Kindness', 'Describe a moment when a simple act of kindness you extended made a big difference in someone’s day.', 'public', 'private', '/uploads/user_diary_images/1736838228537.png', 2, '2025-01-14 07:03:48', 'General', 0, 1, 0, 2, NULL, 0, '2025-01-28 06:45:50'),
(437, 58, 'Bridging the Gap', 'Write about a time you helped bridge a gap between genders, creating understanding and collaboration.', 'public', 'public', '', 2, '2025-01-14 07:05:29', 'General', 1, 1, 0, 4, NULL, 0, '2025-01-28 07:59:44'),
(438, 54, 'My Future Dreams', 'Write about your ambitions and what you aspire to achieve in the future. Discuss your motivation and plans to reach your goals.', 'public', 'private', '/uploads/user_diary_images/1736839122879.png', 0, '2025-01-14 07:18:42', 'General', 0, 0, 0, 0, NULL, 0, '2025-01-22 09:27:21'),
(439, 60, 'The Surprise Hug', 'Out of nowhere, my little sister hugged me today. She didn’t say why, but it made me feel so loved.', 'public', 'private', '/uploads/user_diary_images/1736839282903.png', 0, '2025-01-14 07:21:22', 'General', 0, 1, 0, 2, NULL, 0, '2025-01-22 09:27:18'),
(440, 60, 'The Smell of Cookies', 'I walked past a bakery today, and the smell of cookies reminded me of being a kid. It’s funny how smells can bring back so many memories.', 'public', 'public', '', 0, '2025-01-14 07:23:05', 'General', 0, 0, 0, 0, NULL, 0, '2025-01-22 09:27:14'),
(442, 65, 'The Little Victory', 'I finished a book today that I’d been struggling to read for weeks. It’s not a big deal, but it felt like a win.', 'public', 'private', '/uploads/user_diary_images/1736839752543.png', 0, '2025-01-14 07:29:12', 'General', 0, 0, 0, 0, NULL, 0, '2025-01-22 09:27:16'),
(443, 65, 'The Classroom Giggles', 'Someone made a joke in class today, and we all laughed until the teacher told us to stop. I don’t even remember the joke, but the laughter stayed with me.', 'public', 'public', '', 0, '2025-01-14 07:29:56', 'General', 0, 1, 0, 4, NULL, 0, '2025-01-22 09:27:11'),
(444, 67, 'The Red Balloon', '\r\nI saw a kid lose their red balloon today. It floated up into the sky, and they cried. It reminded me how some things are just out of our control.', 'public', 'public', '/uploads/user_diary_images/1736840636310.png', 0, '2025-01-14 07:43:56', 'General', 0, 0, 0, 0, NULL, 0, '2025-01-22 09:27:04'),
(445, 67, ' The Long Line', '\r\nI stood in line forever at the coffee shop today. I almost left, but then I started talking to the person behind me. It made the wait worth it.', 'public', 'private', NULL, 0, '2025-01-14 07:44:11', 'General', 0, 0, 0, 0, NULL, 0, '2025-01-22 09:27:08'),
(479, 82, 'CHeck', 'Help', 'public', 'private', '', 0, '2025-01-28 10:42:41', 'Domestic Violence', 1, 1, 0, 0, NULL, 0, '2025-01-28 18:42:41');

-- --------------------------------------------------------

--
-- Table structure for table `engagement`
--

CREATE TABLE `engagement` (
  `engagementID` int(11) NOT NULL,
  `entryID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `type` enum('view','like','comment','flag') NOT NULL,
  `timestamp` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `faq`
--

CREATE TABLE `faq` (
  `faqID` int(11) NOT NULL,
  `question` varchar(255) NOT NULL,
  `answer` text NOT NULL,
  `count` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `faq`
--

INSERT INTO `faq` (`faqID`, `question`, `answer`, `count`) VALUES
(1, 'What causes gender-based crimes?', 'Gender-based crimes are often caused by:  Deeply rooted gender inequalities Societal norms that normalize violence or discrimination Power imbalances in relationships and institutions Lack of education or awareness about gender rights Weak enforcement of laws protecting victims', 0),
(2, ' Who are the most common victims of gender-based crimes?', 'While anyone can be a victim of gender-based crimes, the majority of victims are women, girls, and members of the LGBTQ+ community. Men can also be victims, particularly in cases of domestic violence or sexual assault, though these cases are often underreported.', 0),
(3, 'What are gender-based crimes?', 'Gender-based crimes are crimes committed against individuals based on their gender or gender identity. These crimes are often rooted in systemic inequalities, discrimination, and gender stereotypes. Examples include domestic violence, sexual harassment, rape, human trafficking, honor killings, and female genital mutilation (FGM).', 0);

-- --------------------------------------------------------

--
-- Table structure for table `filter_subjects`
--

CREATE TABLE `filter_subjects` (
  `subjectID` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `count` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `filter_subjects`
--

INSERT INTO `filter_subjects` (`subjectID`, `subject`, `count`) VALUES
(7, 'General', 48),
(33, 'Domestic Violence', 18),
(34, 'Sexual Assault and Rape', 7),
(35, 'Human Trafficking', 0),
(36, 'Cyberstalking and Online Harassment', 0),
(37, 'Forced Marriage and Child Marriage', 1),
(38, 'False Accusations', 0),
(40, 'Cyberbullying ', 1),
(42, 'Hate Crimes', 0);

-- --------------------------------------------------------

--
-- Table structure for table `flagged_reports`
--

CREATE TABLE `flagged_reports` (
  `report_id` int(20) NOT NULL,
  `reasons` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `other_text` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `userID` int(11) NOT NULL,
  `actorID` int(100) NOT NULL,
  `entryID` int(11) NOT NULL,
  `isAddress` tinyint(1) DEFAULT 0,
  `isReviewed` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `flagged_reports`
--

INSERT INTO `flagged_reports` (`report_id`, `reasons`, `other_text`, `created_at`, `userID`, `actorID`, `entryID`, `isAddress`, `isReviewed`) VALUES
(1, 'Harmful', NULL, '2025-01-14 07:45:21', 65, 67, 443, 0, 0),
(2, 'Harassment', NULL, '2025-01-14 07:45:27', 60, 67, 439, 0, 0),
(3, 'Harassment', NULL, '2025-01-14 07:45:38', 58, 67, 436, 0, 0),
(4, 'Gender Violence', NULL, '2025-01-14 07:45:56', 32, 67, 384, 0, 0),
(5, 'Bullying', NULL, '2025-01-14 07:46:06', 32, 67, 386, 0, 0),
(6, 'Bullying', NULL, '2025-01-14 07:46:15', 53, 67, 389, 0, 0),
(7, 'Nudity and sexual activity, Bullying or harrassment, Suicide, self-injury or eating disorder', NULL, '2025-01-17 03:28:08', 32, 78, 456, 0, 0),
(8, 'Bullying or harrassment', NULL, '2025-01-27 08:47:17', 54, 69, 382, 0, 0),
(9, 'Bullying or harrassment', NULL, '2025-01-27 12:00:50', 54, 69, 382, 0, 0),
(10, 'Nudity and sexual activity', NULL, '2025-01-27 12:00:54', 54, 69, 382, 0, 0),
(11, 'Nudity and sexual activity', NULL, '2025-01-27 23:55:18', 53, 32, 387, 0, 0),
(12, 'Bullying or harrassment', NULL, '2025-01-28 05:24:25', 53, 79, 315, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `flagging_options`
--

CREATE TABLE `flagging_options` (
  `flagID` int(11) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `count` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `flagging_options`
--

INSERT INTO `flagging_options` (`flagID`, `reason`, `count`) VALUES
(29, 'Nudity and sexual activity', 3),
(30, 'Bullying or harrassment', 4),
(31, 'Suicide, self-injury or eating disorder', 0),
(32, 'Violence, hate or exploitation', 0),
(33, 'Selling or promoting retricted items', 0),
(34, 'Scam, fraud or impersonation', 0);

-- --------------------------------------------------------

--
-- Table structure for table `followers`
--

CREATE TABLE `followers` (
  `userID` int(11) NOT NULL,
  `followedUserID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `followers`
--

INSERT INTO `followers` (`userID`, `followedUserID`) VALUES
(30, 31),
(30, 32),
(30, 53),
(30, 54),
(30, 65),
(32, 30),
(32, 31),
(32, 53),
(32, 54),
(32, 56),
(32, 58),
(32, 66),
(32, 69),
(32, 78),
(53, 30),
(54, 30),
(54, 32),
(54, 53),
(56, 29),
(56, 32),
(58, 30),
(58, 32),
(58, 57),
(59, 29),
(60, 29),
(61, 29),
(61, 60),
(62, 29),
(63, 29),
(64, 29),
(65, 29),
(65, 53),
(65, 58),
(65, 60),
(66, 29),
(67, 29),
(67, 66),
(68, 29),
(69, 29),
(69, 30),
(69, 31),
(69, 32),
(69, 53),
(69, 54),
(69, 59),
(69, 60),
(69, 62),
(69, 63),
(69, 66),
(70, 29),
(72, 29),
(73, 29),
(74, 29),
(75, 29),
(76, 29),
(77, 29),
(78, 29),
(78, 32),
(79, 29),
(79, 57),
(80, 29),
(81, 29),
(82, 29);

-- --------------------------------------------------------

--
-- Table structure for table `gadify_actions`
--

CREATE TABLE `gadify_actions` (
  `gadifyID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `entryID` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `action_taken` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gadify_actions`
--

INSERT INTO `gadify_actions` (`gadifyID`, `userID`, `entryID`, `created_at`, `action_taken`) VALUES
(119, 32, 118, '2024-12-12 16:57:51', NULL),
(155, 29, 118, '2025-01-05 19:16:16', NULL),
(159, 53, 120, '2025-01-06 15:50:47', NULL),
(162, 57, 119, '2025-01-07 11:30:33', NULL),
(163, 58, 119, '2025-01-07 13:26:27', NULL),
(168, 54, 308, '2025-01-07 14:14:34', NULL),
(171, 29, 308, '2025-01-07 14:50:20', NULL),
(178, 64, 388, '2025-01-09 07:47:01', NULL),
(188, 32, 389, '2025-01-10 06:08:42', NULL),
(191, 29, 383, '2025-01-11 05:59:19', NULL),
(203, 58, 435, '2025-01-14 06:58:40', NULL),
(204, 58, 437, '2025-01-14 07:24:02', NULL),
(214, 32, 119, '2025-01-14 12:18:15', NULL),
(224, 54, 386, '2025-01-14 12:26:43', NULL),
(257, 32, 386, '2025-01-14 15:39:56', NULL),
(260, 29, 386, '2025-01-14 18:05:30', NULL),
(270, 78, 386, '2025-01-17 23:07:44', NULL),
(271, 29, 319, '2025-01-27 22:22:45', NULL),
(272, 29, 315, '2025-01-27 22:22:46', NULL),
(273, 29, 435, '2025-01-27 22:22:49', NULL),
(274, 29, 434, '2025-01-27 22:22:52', NULL),
(275, 29, 436, '2025-01-27 22:22:54', NULL),
(276, 69, 120, '2025-01-27 22:30:01', NULL),
(277, 32, 436, '2025-01-27 22:45:50', NULL),
(278, 32, 437, '2025-01-27 23:53:05', NULL),
(279, 29, 387, '2025-01-27 23:54:45', NULL),
(280, 29, 120, '2025-01-28 03:00:52', NULL),
(282, 32, 120, '2025-01-28 03:01:22', NULL),
(283, 79, 434, '2025-01-28 05:23:42', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `gender_based_crime_reports`
--

CREATE TABLE `gender_based_crime_reports` (
  `reportID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `victimName` varchar(255) NOT NULL,
  `perpetratorName` varchar(255) NOT NULL,
  `contactInfo` varchar(255) NOT NULL,
  `gender` enum('male','female','non-binary','prefer not to say') NOT NULL,
  `incidentDescription` text NOT NULL,
  `location` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `supportingDocuments` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `subjects` varchar(255) DEFAULT NULL,
  `isAddress` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gender_based_crime_reports`
--

INSERT INTO `gender_based_crime_reports` (`reportID`, `userID`, `victimName`, `perpetratorName`, `contactInfo`, `gender`, `incidentDescription`, `location`, `date`, `supportingDocuments`, `created_at`, `subjects`, `isAddress`) VALUES
(1, 57, 'Sarah Thompson', '', '09254586523', 'male', 'A male colleague made inappropriate remarks during a team meeting, making her feel uncomfortable.  ', 'In the breakroom', '2024-07-11', '[\"/uploads/gender_based_incidents/1736837748522.jfif\"]', '2025-01-14 06:55:48', 'None(no subject or topic)', 0),
(2, 58, '', 'Ahmed Khan  ', '09458594621', 'prefer not to say', ' Encountered repeated harassment from a supervisor regarding his gender expression.  \r\n', ' Near the office parking lot  ', '2024-10-30', '[\"/uploads/gender_based_incidents/1736838842290.png\"]', '2025-01-14 07:14:02', 'Bullying', 0),
(3, 65, '', 'Liam Anderson  ', '03458249674', 'male', 'Was bullied by a peer for expressing support for women’s rights in the workplace.  \r\n', 'On the office terrace ', '2024-10-23', '[\"/uploads/gender_based_incidents/1736839880401.jfif\"]', '2025-01-14 07:31:20', 'None(no subject or topic)', 0),
(4, 65, '', 'Liam Anderson  ', '03458249674', 'male', 'Was bullied by a peer for expressing support for women’s rights in the workplace.  \r\n', 'On the office terrace ', '2024-10-23', '[\"/uploads/gender_based_incidents/1736839880878.jfif\"]', '2025-01-14 07:31:20', 'None(no subject or topic)', 1),
(5, 30, '', 'Ethan White     ', '09748562146', 'prefer not to say', ' A manager openly mocked his preference for gender-inclusive language in a presentation.  \r\n', 'In the training room  ', '2024-11-21', '[\"/uploads/gender_based_incidents/1736840376885.jfif\"]', '2025-01-14 07:39:36', 'Domestic Violence', 0);

-- --------------------------------------------------------

--
-- Table structure for table `index_images`
--

CREATE TABLE `index_images` (
  `index_imagesID` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `image_path` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `index_images`
--

INSERT INTO `index_images` (`index_imagesID`, `title`, `description`, `image_path`, `created_at`) VALUES
(7, 'GENDER AND DEVELOPMENT', 'CvSU - CCAT Gender and Development', '/uploads/1735041914933.jpg', '2024-12-24 12:05:14'),
(16, 'International Women\'s Day', 'Join us in celebrating national women\'s day!', '/uploads/1738039456766.jpg', '2025-01-28 04:44:16'),
(17, '#endVAWph', 'Let\'s end Violence Against Women!', '/uploads/1738039534491.jpg', '2025-01-28 04:45:34');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `messageID` int(11) NOT NULL,
  `senderID` int(11) NOT NULL,
  `recipientID` int(11) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `isAdmin` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`messageID`, `senderID`, `recipientID`, `message`, `created_at`, `isAdmin`) VALUES
(231, 79, 29, 'Hello po', '2025-01-28 05:23:54', 1),
(232, 29, 79, 'Kamusta ka?', '2025-01-28 05:24:03', 1),
(233, 80, 29, 'Hello', '2025-01-28 10:22:08', 1),
(234, 82, 29, 'Hello', '2025-01-28 10:42:24', 1);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `notificationID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `actorID` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `entryID` int(11) DEFAULT NULL,
  `type` enum('gadify','follow','unfollow','comment') NOT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `profile_image` varchar(255) NOT NULL,
  `read` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`notificationID`, `userID`, `actorID`, `message`, `entryID`, `type`, `timestamp`, `profile_image`, `read`) VALUES
(327, 29, 79, 'A diary entry containing alarming words has been posted by Jem Llanto Llanto', 478, '', '2025-01-28 13:23:13', '/uploads/profile_pictures/1738041740853.jpg', 1),
(328, 57, 79, 'Jem Llanto Llanto has followed you.', NULL, 'follow', '2025-01-28 13:23:40', '/uploads/profile_pictures/1738041740853.jpg', 0),
(329, 57, 79, 'Jem Llanto Llanto gadified your diary entry.', 434, 'gadify', '2025-01-28 13:23:42', '/uploads/profile_pictures/1738041740853.jpg', 0),
(330, 57, 79, 'Jem Llanto Llanto commented on your diary entry.', 434, 'comment', '2025-01-28 13:23:46', '/uploads/profile_pictures/default.png', 0),
(331, 29, 82, 'A diary entry containing alarming words has been posted by Jem Llanto', 479, '', '2025-01-28 18:42:41', '/uploads/profile_pictures/default.png', 1);

-- --------------------------------------------------------

--
-- Table structure for table `reported_users`
--

CREATE TABLE `reported_users` (
  `reportedUsersID` int(11) NOT NULL,
  `userID` int(11) DEFAULT NULL,
  `reportedUserID` int(11) DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `isAddress` tinyint(1) NOT NULL DEFAULT 0,
  `isReviewed` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reported_users`
--

INSERT INTO `reported_users` (`reportedUsersID`, `userID`, `reportedUserID`, `reason`, `created_at`, `isAddress`, `isReviewed`) VALUES
(2, 32, 32, 'Hate Speech', '2025-01-14 07:52:36', 0, 0),
(3, 58, 58, 'Violence, hate or exploitation', '2025-01-28 02:24:10', 0, 0),
(4, 53, 53, 'Bullying or harrassment', '2025-01-28 02:24:40', 0, 0),
(5, 53, 53, 'Bullying or harrassment', '2025-01-28 05:24:37', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `reporting_users`
--

CREATE TABLE `reporting_users` (
  `reportingUserID` int(11) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `count` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reporting_users`
--

INSERT INTO `reporting_users` (`reportingUserID`, `reason`, `count`) VALUES
(19, 'Nudity and sexual activity', 0),
(20, 'Bullying or harrassment', 2),
(21, 'Suicide, self-injury or eating disorder', 0),
(22, 'Violence, hate or exploitation', 0),
(23, 'Selling or promoting retricted items', 0),
(24, 'Scam, fraud or impersonation', 0);

-- --------------------------------------------------------

--
-- Table structure for table `report_comments`
--

CREATE TABLE `report_comments` (
  `reportCommentID` int(11) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `count` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `report_comments`
--

INSERT INTO `report_comments` (`reportCommentID`, `reason`, `count`) VALUES
(20, 'Nudity and sexual activity', 0),
(21, 'Bullying or harrassment', 0),
(22, 'Suicide, self-injury or eating disorder', 0),
(23, 'Violence, hate or exploitation', 0),
(24, 'Selling or promoting retricted items', 0),
(25, 'Scam, fraud or impersonation', 0);

-- --------------------------------------------------------

--
-- Table structure for table `suspensions`
--

CREATE TABLE `suspensions` (
  `suspensionID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `suspendUntil` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_filters`
--

CREATE TABLE `user_filters` (
  `user_filterID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `filter` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_filters`
--

INSERT INTO `user_filters` (`user_filterID`, `userID`, `filter`, `created_at`) VALUES
(46, 30, 'Cyberstalking and Online Harassment', '2025-01-22 06:10:05'),
(48, 30, 'False Accusations', '2025-01-22 06:10:05'),
(50, 30, 'Hate Crimes', '2025-01-22 06:10:05'),
(51, 30, 'Domestic Violence', '2025-01-22 06:10:05'),
(52, 30, 'Sexual Assault and Rape', '2025-01-22 06:10:05'),
(53, 30, 'Human Trafficking', '2025-01-22 06:10:11'),
(54, 30, 'General', '2025-01-22 06:10:11'),
(55, 30, 'Forced Marriage and Child Marriage', '2025-01-22 06:10:11'),
(56, 30, 'Cyberbullying ', '2025-01-22 06:10:11'),
(97, 32, 'General', '2025-01-22 06:24:03'),
(98, 32, 'Domestic Violence', '2025-01-22 06:24:03'),
(99, 32, 'Sexual Assault and Rape', '2025-01-22 06:24:03'),
(100, 32, 'Human Trafficking', '2025-01-22 06:24:03'),
(101, 32, 'Cyberstalking and Online Harassment', '2025-01-22 06:24:03'),
(102, 32, 'Forced Marriage and Child Marriage', '2025-01-22 06:24:03'),
(103, 32, 'False Accusations', '2025-01-22 06:24:03'),
(104, 32, 'Cyberbullying ', '2025-01-22 06:24:03'),
(105, 32, 'Hate Crimes', '2025-01-22 06:24:03'),
(106, 57, 'General', '2025-01-22 06:27:42'),
(107, 57, 'Domestic Violence', '2025-01-22 06:27:42'),
(108, 57, 'Sexual Assault and Rape', '2025-01-22 06:27:42'),
(109, 57, 'Human Trafficking', '2025-01-22 06:27:42'),
(110, 57, 'Cyberstalking and Online Harassment', '2025-01-22 06:27:42'),
(111, 57, 'Forced Marriage and Child Marriage', '2025-01-22 06:27:42'),
(112, 57, 'False Accusations', '2025-01-22 06:27:42'),
(113, 57, 'Cyberbullying ', '2025-01-22 06:27:42'),
(114, 57, 'Hate Crimes', '2025-01-22 06:27:42'),
(128, 79, 'General', '2025-01-28 05:22:01'),
(129, 79, 'Domestic Violence', '2025-01-28 05:22:01'),
(130, 79, 'Sexual Assault and Rape', '2025-01-28 05:22:01'),
(131, 79, 'Human Trafficking', '2025-01-28 05:22:01'),
(132, 79, 'Cyberstalking and Online Harassment', '2025-01-28 05:22:01'),
(133, 79, 'Forced Marriage and Child Marriage', '2025-01-28 05:22:01'),
(134, 79, 'False Accusations', '2025-01-28 05:22:01'),
(135, 79, 'Cyberbullying ', '2025-01-28 05:22:01'),
(136, 79, 'Hate Crimes', '2025-01-28 05:22:01'),
(137, 80, 'Domestic Violence', '2025-01-28 10:20:54'),
(138, 80, 'Sexual Assault and Rape', '2025-01-28 10:20:54'),
(139, 82, 'General', '2025-01-28 10:41:30'),
(140, 82, 'Domestic Violence', '2025-01-28 10:41:30'),
(141, 82, 'Sexual Assault and Rape', '2025-01-28 10:41:30'),
(142, 82, 'Human Trafficking', '2025-01-28 10:41:30'),
(143, 82, 'Cyberstalking and Online Harassment', '2025-01-28 10:41:30'),
(144, 82, 'Forced Marriage and Child Marriage', '2025-01-28 10:41:30'),
(145, 82, 'False Accusations', '2025-01-28 10:41:30'),
(146, 82, 'Cyberbullying ', '2025-01-28 10:41:30'),
(147, 82, 'Hate Crimes', '2025-01-28 10:41:30');

-- --------------------------------------------------------

--
-- Table structure for table `user_profiles`
--

CREATE TABLE `user_profiles` (
  `profileID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `bio` text DEFAULT NULL,
  `alias` varchar(50) DEFAULT NULL,
  `followersCount` int(11) DEFAULT 0,
  `followingCount` int(11) DEFAULT 0,
  `profile_image` varchar(255) NOT NULL DEFAULT '/uploads/profile_pictures/default.png'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_profiles`
--

INSERT INTO `user_profiles` (`profileID`, `userID`, `bio`, `alias`, `followersCount`, `followingCount`, `profile_image`) VALUES
(15, 29, 'Don\'t be afraid we  are here to HELP YOU! ', 'Admin', 0, 0, '/uploads/profile_pictures/1736652184543.jpg'),
(16, 30, 'In Jesus name, makakapasa kami. <3', 'Effie', 5, 6, '/uploads/profile_pictures/1736262528177.jpg'),
(17, 31, 'Helloa', 'Pogi', 3, 0, '/uploads/profile_pictures/1735564058601.png'),
(18, 32, 'Masayahin pero seryoso...‼️‼️‼️', 'Medge', 7, 10, '/uploads/profile_pictures/NewProject16CBD4B9-ezgif.com-video-to-gif-converter (1).gif'),
(32, 53, NULL, 'Waldo', 5, 1, '/uploads/profile_pictures/1735564103823.jpg'),
(33, 54, 'best random website\n', 'Jekjek', 11, 11, '/uploads/profile_pictures/1736838974511.png'),
(35, 56, NULL, 'MEJ', 1, 0, '/uploads/profile_pictures/default.png'),
(36, 57, NULL, 'amo', 2, 0, '/uploads/profile_pictures/1736235608439.jpg'),
(37, 58, 'Hello Kamusta Kayo', 'Eddie', 2, 3, '/uploads/profile_pictures/1736256694123.jpg'),
(38, 59, NULL, 'Zxhi', 1, 0, '/uploads/profile_pictures/1736261333109.jpg'),
(39, 60, NULL, 'Chin', 3, 0, '/uploads/profile_pictures/1736262239202.jpg'),
(40, 61, 'asdf', 'sayi', 0, 1, '/uploads/profile_pictures/1736263211528.jpg'),
(41, 62, NULL, 'Nowi', 1, 0, '/uploads/profile_pictures/1736264662965.jpg'),
(42, 63, NULL, 'Shanna Maemae', 1, 0, '/uploads/profile_pictures/1736265926424.jpg'),
(43, 64, 'hi', 'nicole', 0, 0, '/uploads/profile_pictures/1736408879565.jpg'),
(44, 65, NULL, 'Maki', 1, 3, '/uploads/profile_pictures/1736839673941.png'),
(45, 66, 'hello', 'jade', 3, 0, '/uploads/profile_pictures/1736416362292.jpg'),
(46, 67, 'hello sa inyo', 'Mirai', 0, 1, '/uploads/profile_pictures/1736840435593.jpg'),
(47, 68, 'HELLO SA INYO', 'totoy', 0, 0, '/uploads/profile_pictures/default.png'),
(48, 69, 'Hello Kamusta kayo', 'BemBem', 1, 10, '/uploads/profile_pictures/1737968044509.jpg'),
(56, 78, NULL, 'Evad', 1, 1, '/uploads/profile_pictures/default.png'),
(58, 80, NULL, 'Mej', 0, 0, '/uploads/profile_pictures/default.png'),
(59, 81, NULL, 'Mej', 0, 0, '/uploads/profile_pictures/default.png'),
(60, 82, NULL, 'Mej', 0, 0, '/uploads/profile_pictures/default.png');

-- --------------------------------------------------------

--
-- Table structure for table `user_table`
--

CREATE TABLE `user_table` (
  `userID` int(11) NOT NULL,
  `isNewAccount` int(11) NOT NULL DEFAULT 1,
  `isAdmin` int(10) NOT NULL,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `cvsuEmail` varchar(100) NOT NULL,
  `studentNumber` int(9) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `verificationToken` varchar(255) DEFAULT NULL,
  `isVerified` tinyint(1) DEFAULT 0,
  `sex` varchar(10) NOT NULL,
  `course` varchar(50) NOT NULL,
  `year` varchar(10) NOT NULL,
  `isActive` tinyint(1) DEFAULT 0,
  `suspendReason` varchar(255) DEFAULT NULL,
  `suspendUntil` datetime DEFAULT NULL,
  `isSuspended` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_table`
--

INSERT INTO `user_table` (`userID`, `isNewAccount`, `isAdmin`, `firstName`, `lastName`, `cvsuEmail`, `studentNumber`, `username`, `password`, `created_at`, `verificationToken`, `isVerified`, `sex`, `course`, `year`, `isActive`, `suspendReason`, `suspendUntil`, `isSuspended`) VALUES
(29, 1, 1, 'Gender and Development', '- GAD', 'gadccat@cvsu.edu.ph', 202110583, 'Gender and Development', '$2a$10$JUFMyhlgnXZlqhs19aR/BujlXnwH83wwOohgK.0FKH9mBifsdd3Ka', '2024-09-30 17:14:36', NULL, 0, '', '', '', 0, '', NULL, 0),
(30, 0, 0, 'John Kenneth', 'Tan', 'johnkenneth.tan@yahoo.com', 1234567890, 'Dave', '$2a$10$YhIZgS.KpDiNV14dF0sPwuynVu/U/ob.jpbQvZMMU.5Ay3mIo6472', '2024-09-30 17:15:28', NULL, 0, 'Female', 'BS Information Technology', '3rd', 0, '', NULL, 0),
(31, 1, 0, 'John Victor', 'Silva', 'johnvictor.silva@cvsu.edu', 2147483647, 'Vic', '$2a$10$UCP2K1MtvYhAiHE3qXiNaueL5PCE3IUZjLqwTLVOR/6K5YUH5qoHq', '2024-09-30 17:16:16', NULL, 0, 'Male', 'BS Industrial Technology', '4th', 0, 'Bullying', NULL, 0),
(32, 0, 0, 'Jem', 'Llanto', 'jemmari.llanto@cvsu.edu.ph', 2147483647, 'Hatdog', '$2a$10$aDAPUYPQuzaJjJqJPUGSjONloaNU.8iKcVFh1PMJQsRQIJcfQPAlC', '2024-10-03 14:03:06', NULL, 0, 'Male', 'BS Information Technology', '2nd', 0, 'Inappropriate Remarks', NULL, 0),
(53, 1, 0, 'John Mark', 'Sallao', 'johnmark.sallao@cvsu.edu.ph', 202110575, 'jm', '$2a$10$3QYSYAQQ3QH1MYNk9G2N7umDkN7tQRPV5RUUd7Jnxzzks.kJkBklq', '2024-11-27 15:49:11', '4ee84fc0e5903eb7a239ef23b806f77123835527', 1, 'Prefer not', 'BS Computer Engineering', '1st', 0, 'Harmful Comment', NULL, 0),
(54, 1, 0, 'Erik Carl', 'Rosete', 'erikcarl.rosete@cvsu.edu.ph', 202110573, 'Erik', '$2a$10$pgg2hiAM/DxUkP9IIR2nVeXnwCjTZs3v2T3717YcXhkKz9QJtcecC', '2024-11-27 16:06:04', '358eaee229fde2f99334b75d190909e5dc9b88dd', 1, 'Female', 'BS Computer Science', '2nd', 0, NULL, NULL, 0),
(57, 0, 0, 'ANA MARIE', 'OBON', 'anamarie.obon@cvsu.edu.ph', 202200038, '202200038', '$2a$10$jJ8wMSxPNCAKlLYIeULedOQIz7iMWk4SNySdwsEIwgCK3z4g2uOAW', '2025-01-07 07:38:21', 'ceaf4db75e6e548373a6221c9ea8b72cffae8b63', 1, 'Female', 'BS Information Technology', '1st', 0, NULL, NULL, 0),
(58, 1, 0, 'Eduardo', 'Tacorda', 'eduardo.tacorda@cvsu.edu.ph', 202010933, 'Eduardo', '$2a$10$ncTnq.H/lHoLyhhqKUgPluq5FA0qkg50v3M9AJuR70i7Ugi.GqD96', '2025-01-07 13:20:06', '042c61082f793e189f2a1982783297d88f845dd6', 1, 'Male', 'BS Information Technology', '4th', 0, NULL, NULL, 0),
(59, 1, 0, 'Michelle', 'Villavilla', 'michelle.villavilla@cvsu.edu.ph', 202110714, 'zxhi_username', '$2a$10$UC0DO8bUdNADB9itORx9FOoQEB4R2MCsdg8FAKjwYGHgtvnM0dDdC', '2025-01-07 14:45:50', 'f7918e53ddafde8b3dfc75a5a2b7a5eba1b4c112', 1, 'Female', 'BS Information Technology', '4th', 0, NULL, NULL, 0),
(60, 1, 0, 'Francine Kate', 'Timpoc', 'francinekate.timpoc@cvsu.edu.ph', 202110589, 'Chin_2', '$2a$10$OzicLY.mO6O7aa8BeT8NqeQZ5lkSmlu1SGqaRneQNLEIbFYDYpqCm', '2025-01-07 15:00:55', '6c224731764af5207f19f06c44a46659853827a9', 1, 'Female', 'BS Information Technology', '4th', 0, NULL, NULL, 0),
(61, 1, 0, 'Zylei', 'Sugue', 'zylei.sugue@cvsu.edu.ph', 202110712, 'zylei.sugue@cvsu.edu.ph', '$2a$10$l.N7dhf2jVbuv2MMOTaKGechPZAWajZUHNhUjIMXgBpEcrYKEGcIe', '2025-01-07 15:15:25', 'a9504e804a776d2d2056cbeaa9866a624a169b56', 1, 'Female', 'BS Information Technology', '4th', 0, NULL, NULL, 0),
(62, 1, 0, 'Noely', 'Reyes', 'noely.reyes@cvsu.edu.ph', 202110570, 'noely.reyes@cvsu.edu.ph', '$2a$10$OJIXWCfL8.N9qmD9eWwuwOzEyRUd8mvnUDGR3.maPU.d2AI1ZBaLm', '2025-01-07 15:42:21', '1e5bfb19192d57575505605d8cba32e37d95d5c4', 1, 'Female', 'BS Information Technology', '4th', 0, NULL, NULL, 0),
(63, 1, 0, 'Shanna', 'Remoto', 'shannamae.remoto@cvsu.edu.ph', 202110569, 'shannamae@cvsu.edu.ph', '$2a$10$xbSi2UpRmXUQwtERmKkCy.AzdSuavcS2sNM4JEaetBgyrgiC5Rs02', '2025-01-07 16:04:26', 'dbaa1968a993ed3e2242752d4d185fbabca3130b', 1, 'Female', 'BS Information Technology', '4th', 0, NULL, NULL, 0),
(64, 1, 0, 'ennairrah', 'tamio', 'harriannenicole.tamio@cvsu.edu.ph', 202110586, 'harriannenicole.tamio@cvsu.edu.ph', '$2a$10$Vmdng9GQgkf1dGHhIpU71eC1FxDHem0MPo.e3fa0lSEzai1c5sJZy', '2025-01-09 07:46:24', 'e4d81e197f397bc8e615bdee1814577d3f7fff5e', 1, 'Female', 'BS Information Technology', '4th', 0, 'Hate Speech', NULL, 0),
(65, 1, 0, 'Mark Christian', 'Naval', 'markchistian.naval@cvsu.edu.ph', 202111220, 'markchistian.naval@cvsu.edu.ph', '$2a$10$7AHSrYYHCCkaXcxhL81qmOby.3hwd2b8XZeXFxGIIIllN1zeDljFG', '2025-01-09 08:58:31', '1d9333747aca09b46034ac8bd5f3a1e5f44f7f5c', 1, 'Male', 'BS Information Technology', '4th', 0, NULL, NULL, 0),
(66, 1, 0, 'jaidey', 'madolid', 'jaideymeimadolid@cvsu.edu.ph', 202410226, 'jaideymeimadolid@cvsu.edu.ph', '$2a$10$I7GoCd25hzvgECVxxQaIBe/B8pe5Vkdqw7qlyxJTqE.wn/7DKwYO.', '2025-01-09 09:47:32', '518edaf0f77d5ef9e298a9751aceec6c144cba44', 1, 'Female', 'BS Business Management', '1st', 0, 'Harmful Comment', '2025-04-12 11:43:23', 1),
(67, 1, 0, 'Marco', 'Dala', 'johnmarco.doblados@cvsu.edu.ph', 202110694, 'johnmarco.doblados@cvsu.edu.ph', '$2a$10$JvVQ9XjyQr1H3S.jgDxOnudgW6KdI6oDvgUu8msF8fJgw01c1nP5S', '2025-01-09 10:06:41', 'cf405f2851d2ede92976255b70d5ff2f0953fa3d', 1, 'Male', 'BS Information Technology', '4th', 0, NULL, NULL, 0),
(68, 1, 0, 'ojen', 'dimagiba', 'justine.barrameda@cvsu.edu.ph', 202411692, 'justine.barrameda@cvsu.edu.ph', '$2a$10$VceItmYE6.W1ZGZfgvKs6ejmSTtLHdvv70KTn9tKIESwMr2yJWOHK', '2025-01-10 07:41:41', 'ecfacdb355bc7acf239dbc9025b43678681bed0f', 1, 'Prefer not', 'BS Industrial Technology', '1st', 0, '', NULL, 0),
(69, 0, 0, 'Eraseo', 'LLanto', 'jemllanto@cvsu.edu.ph', 202010933, 'jemllanto@cvsu.edu.ph', '$2a$10$d6IoHpOvGeHviF5hrNocvOQUD88RoAroQMq2eDksDg7VrSjP7efUu', '2025-01-11 06:14:08', '783337b21e7b8396e1705949c9fbb135693eea70', 1, 'Male', 'BS Information Technology', '4th', 1, NULL, NULL, 0),
(78, 0, 0, 'Dave', 'Tan', 'dave.tan@cvsu.edu.ph', 202014788, 'dave.tan@cvsu.edu.ph', '$2a$10$7nRZtEcM8H9.fBaXI5c77eeXuUCqcsCoyBZa.5COU3GLERMJpAX5K', '2025-01-14 07:54:46', '3ff19268dcea659b5ab9930425ea84f8d36bb9fb', 1, 'Male', 'BS Hospitality Management', '1st', 0, NULL, NULL, 0),
(82, 0, 0, 'Jem', 'Llanto', 'janeraseomari.llanto@cvsu.edu.ph', 202010933, 'janeraseomari.llanto@cvsu.edu.ph', '$2a$10$wQ1NbagMGCNCxhYQE/KozeW0AJ/Rd7OCVTdUmdSO1kJh22Q5apmkS', '2025-01-28 10:41:06', 'bd90bdc5a4818c5fcbd4a44496b06f06709aa78c', 1, 'Male', 'BS Information Technology', '3rd', 0, NULL, NULL, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alarming_words`
--
ALTER TABLE `alarming_words`
  ADD PRIMARY KEY (`wordID`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`commentID`);

--
-- Indexes for table `comment_reports`
--
ALTER TABLE `comment_reports`
  ADD PRIMARY KEY (`reportcommentID`),
  ADD KEY `commentID` (`commentID`),
  ADD KEY `userID` (`userID`);

--
-- Indexes for table `diary_entries`
--
ALTER TABLE `diary_entries`
  ADD PRIMARY KEY (`entryID`);

--
-- Indexes for table `engagement`
--
ALTER TABLE `engagement`
  ADD PRIMARY KEY (`engagementID`);

--
-- Indexes for table `faq`
--
ALTER TABLE `faq`
  ADD PRIMARY KEY (`faqID`);

--
-- Indexes for table `filter_subjects`
--
ALTER TABLE `filter_subjects`
  ADD PRIMARY KEY (`subjectID`);

--
-- Indexes for table `flagged_reports`
--
ALTER TABLE `flagged_reports`
  ADD PRIMARY KEY (`report_id`);

--
-- Indexes for table `flagging_options`
--
ALTER TABLE `flagging_options`
  ADD PRIMARY KEY (`flagID`);

--
-- Indexes for table `followers`
--
ALTER TABLE `followers`
  ADD PRIMARY KEY (`userID`,`followedUserID`),
  ADD KEY `followedUserID` (`followedUserID`);

--
-- Indexes for table `gadify_actions`
--
ALTER TABLE `gadify_actions`
  ADD PRIMARY KEY (`gadifyID`),
  ADD KEY `userID` (`userID`),
  ADD KEY `entryID` (`entryID`);

--
-- Indexes for table `gender_based_crime_reports`
--
ALTER TABLE `gender_based_crime_reports`
  ADD PRIMARY KEY (`reportID`);

--
-- Indexes for table `index_images`
--
ALTER TABLE `index_images`
  ADD PRIMARY KEY (`index_imagesID`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`messageID`),
  ADD KEY `senderID` (`senderID`),
  ADD KEY `recipientID` (`recipientID`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`notificationID`),
  ADD KEY `userID` (`userID`),
  ADD KEY `actorID` (`actorID`);

--
-- Indexes for table `reported_users`
--
ALTER TABLE `reported_users`
  ADD PRIMARY KEY (`reportedUsersID`);

--
-- Indexes for table `reporting_users`
--
ALTER TABLE `reporting_users`
  ADD PRIMARY KEY (`reportingUserID`);

--
-- Indexes for table `report_comments`
--
ALTER TABLE `report_comments`
  ADD PRIMARY KEY (`reportCommentID`);

--
-- Indexes for table `suspensions`
--
ALTER TABLE `suspensions`
  ADD PRIMARY KEY (`suspensionID`),
  ADD KEY `userID` (`userID`);

--
-- Indexes for table `user_filters`
--
ALTER TABLE `user_filters`
  ADD PRIMARY KEY (`user_filterID`);

--
-- Indexes for table `user_profiles`
--
ALTER TABLE `user_profiles`
  ADD PRIMARY KEY (`profileID`),
  ADD KEY `userID` (`userID`);

--
-- Indexes for table `user_table`
--
ALTER TABLE `user_table`
  ADD PRIMARY KEY (`userID`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `alarming_words`
--
ALTER TABLE `alarming_words`
  MODIFY `wordID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `commentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=163;

--
-- AUTO_INCREMENT for table `comment_reports`
--
ALTER TABLE `comment_reports`
  MODIFY `reportcommentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `diary_entries`
--
ALTER TABLE `diary_entries`
  MODIFY `entryID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=480;

--
-- AUTO_INCREMENT for table `engagement`
--
ALTER TABLE `engagement`
  MODIFY `engagementID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `faq`
--
ALTER TABLE `faq`
  MODIFY `faqID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `filter_subjects`
--
ALTER TABLE `filter_subjects`
  MODIFY `subjectID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `flagged_reports`
--
ALTER TABLE `flagged_reports`
  MODIFY `report_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `flagging_options`
--
ALTER TABLE `flagging_options`
  MODIFY `flagID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `gadify_actions`
--
ALTER TABLE `gadify_actions`
  MODIFY `gadifyID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=284;

--
-- AUTO_INCREMENT for table `gender_based_crime_reports`
--
ALTER TABLE `gender_based_crime_reports`
  MODIFY `reportID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `index_images`
--
ALTER TABLE `index_images`
  MODIFY `index_imagesID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `messageID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=235;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `notificationID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=332;

--
-- AUTO_INCREMENT for table `reported_users`
--
ALTER TABLE `reported_users`
  MODIFY `reportedUsersID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `reporting_users`
--
ALTER TABLE `reporting_users`
  MODIFY `reportingUserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `report_comments`
--
ALTER TABLE `report_comments`
  MODIFY `reportCommentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `suspensions`
--
ALTER TABLE `suspensions`
  MODIFY `suspensionID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_filters`
--
ALTER TABLE `user_filters`
  MODIFY `user_filterID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=148;

--
-- AUTO_INCREMENT for table `user_profiles`
--
ALTER TABLE `user_profiles`
  MODIFY `profileID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `user_table`
--
ALTER TABLE `user_table`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comment_reports`
--
ALTER TABLE `comment_reports`
  ADD CONSTRAINT `comment_reports_ibfk_1` FOREIGN KEY (`commentID`) REFERENCES `comments` (`commentID`),
  ADD CONSTRAINT `comment_reports_ibfk_2` FOREIGN KEY (`userID`) REFERENCES `user_table` (`userID`);

--
-- Constraints for table `followers`
--
ALTER TABLE `followers`
  ADD CONSTRAINT `followers_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `user_table` (`userID`),
  ADD CONSTRAINT `followers_ibfk_2` FOREIGN KEY (`followedUserID`) REFERENCES `user_table` (`userID`);

--
-- Constraints for table `gadify_actions`
--
ALTER TABLE `gadify_actions`
  ADD CONSTRAINT `gadify_actions_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `user_table` (`userID`) ON DELETE CASCADE,
  ADD CONSTRAINT `gadify_actions_ibfk_2` FOREIGN KEY (`entryID`) REFERENCES `diary_entries` (`entryID`) ON DELETE CASCADE;

--
-- Constraints for table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`senderID`) REFERENCES `user_table` (`userID`),
  ADD CONSTRAINT `messages_ibfk_2` FOREIGN KEY (`recipientID`) REFERENCES `user_table` (`userID`);

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `user_table` (`userID`),
  ADD CONSTRAINT `notifications_ibfk_2` FOREIGN KEY (`actorID`) REFERENCES `user_table` (`userID`);

--
-- Constraints for table `suspensions`
--
ALTER TABLE `suspensions`
  ADD CONSTRAINT `suspensions_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `user_table` (`userID`);

--
-- Constraints for table `user_profiles`
--
ALTER TABLE `user_profiles`
  ADD CONSTRAINT `user_profiles_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `user_table` (`userID`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
