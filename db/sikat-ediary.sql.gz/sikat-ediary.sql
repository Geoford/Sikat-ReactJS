-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 28, 2024 at 10:33 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sikat-ediary`
--

-- --------------------------------------------------------

--
-- Table structure for table `diary_entries`
--

CREATE TABLE `diary_entries` (
  `entryID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `visibility` enum('public','private') NOT NULL,
  `anonimity` enum('true','false') NOT NULL DEFAULT 'false',
  `fileURL` varchar(255) DEFAULT NULL,
  `gadifyCount` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `followers`
--

CREATE TABLE `followers` (
  `userID` int(55) NOT NULL,
  `followedUserID` int(55) NOT NULL,
  `followingUserID` int(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `gadify_actions`
--

CREATE TABLE `gadify_actions` (
  `gadifyID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `entryID` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_profiles`
--

CREATE TABLE `user_profiles` (
  `profileID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `bio` text DEFAULT NULL,
  `alias` varchar(50) DEFAULT NULL,
  `followersCount` int(11) DEFAULT 0,
  `followingCount` int(11) DEFAULT 0,
  `profile_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_profiles`
--

INSERT INTO `user_profiles` (`profileID`, `userID`, `bio`, `alias`, `followersCount`, `followingCount`, `profile_image`) VALUES
(4, 4, NULL, 'Lando', 0, 0, ''),
(5, 5, NULL, 'Kalbo', 0, 0, ''),
(6, 6, NULL, 'Babage', 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `user_table`
--

CREATE TABLE `user_table` (
  `userID` int(11) NOT NULL,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `cvsuEmail` varchar(100) NOT NULL,
  `studentNumber` int(9) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_table`
--

INSERT INTO `user_table` (`userID`, `firstName`, `lastName`, `cvsuEmail`, `studentNumber`, `username`, `password`, `created_at`) VALUES
(4, 'Jan Eraseo Mari', 'Llanto', 'janeraseomari.llanto@cvsu.edu.ph', 202110583, 'Jem', '$2a$10$cUC9POqjA6p4egoOHwEUdu/BL9PnZJkr8dA5fJrhT3JHNqeRlN5sy', '2024-09-28 08:30:31'),
(5, 'John Kennet', 'Tan', 'johnkenneth.tan@cvsu.edu.ph', 202110581, 'Dave', '$2a$10$o2BGZjPvsJrX9tdaL1LANO1KQwHv4raRS5MiWBaSB/XuWflyEjaK6', '2024-09-28 08:31:29'),
(6, 'John Victor', 'SIlva', 'johnvictor.silva@cvsu.edu.ph', 202110583, 'Jambik', '$2a$10$fCRdS7/R11Q5Mw7Ix5ZAKO.8dUpO5YgFJIDA2QKPR8zNdHy2dDVbi', '2024-09-28 08:32:41');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `diary_entries`
--
ALTER TABLE `diary_entries`
  ADD PRIMARY KEY (`entryID`);

--
-- Indexes for table `followers`
--
ALTER TABLE `followers`
  ADD PRIMARY KEY (`userID`);

--
-- Indexes for table `gadify_actions`
--
ALTER TABLE `gadify_actions`
  ADD PRIMARY KEY (`gadifyID`),
  ADD KEY `userID` (`userID`),
  ADD KEY `entryID` (`entryID`);

--
-- Indexes for table `user_profiles`
--
ALTER TABLE `user_profiles`
  ADD PRIMARY KEY (`profileID`),
  ADD KEY `userID` (`userID`);

--
-- Indexes for table `user_table`
--
ALTER TABLE `user_table`
  ADD PRIMARY KEY (`userID`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `diary_entries`
--
ALTER TABLE `diary_entries`
  MODIFY `entryID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `followers`
--
ALTER TABLE `followers`
  MODIFY `userID` int(55) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `gadify_actions`
--
ALTER TABLE `gadify_actions`
  MODIFY `gadifyID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_profiles`
--
ALTER TABLE `user_profiles`
  MODIFY `profileID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user_table`
--
ALTER TABLE `user_table`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `gadify_actions`
--
ALTER TABLE `gadify_actions`
  ADD CONSTRAINT `gadify_actions_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `user_table` (`userID`) ON DELETE CASCADE,
  ADD CONSTRAINT `gadify_actions_ibfk_2` FOREIGN KEY (`entryID`) REFERENCES `diary_entries` (`entryID`) ON DELETE CASCADE;

--
-- Constraints for table `user_profiles`
--
ALTER TABLE `user_profiles`
  ADD CONSTRAINT `user_profiles_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `user_table` (`userID`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
