-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 23, 2024 at 09:49 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sikat-ediary`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `commentID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `entryID` int(11) NOT NULL,
  `text` text NOT NULL,
  `replyCommentID` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`commentID`, `userID`, `entryID`, `text`, `replyCommentID`, `created_at`) VALUES
(89, 30, 12, 'asd', NULL, '2024-10-21 11:51:13'),
(90, 30, 11, 'a', NULL, '2024-10-21 18:00:44'),
(91, 32, 12, 'a', 89, '2024-10-21 18:19:52'),
(92, 32, 12, 'a', NULL, '2024-10-21 18:20:03');

-- --------------------------------------------------------

--
-- Table structure for table `diary_entries`
--

CREATE TABLE `diary_entries` (
  `entryID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `visibility` enum('public','private') NOT NULL,
  `anonimity` enum('true','false') NOT NULL DEFAULT 'false',
  `diary_image` varchar(255) DEFAULT NULL,
  `gadifyCount` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `subjects` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `diary_entries`
--

INSERT INTO `diary_entries` (`entryID`, `userID`, `title`, `description`, `visibility`, `anonimity`, `diary_image`, `gadifyCount`, `created_at`, `subjects`) VALUES
(9, 29, 'FOLLOW', 'asd', 'public', '', '', 0, '2024-09-30 17:14:58', NULL),
(10, 31, 'asddasdasd', 'asdsad', 'public', '', '', 1, '2024-09-30 17:32:48', NULL),
(11, 30, 'Woah', 'ASDASDASD', 'public', '', NULL, 0, '2024-09-30 17:34:04', NULL),
(12, 32, 'Wowers', 'Opo', 'public', '', '/uploads/1727965443235.jpg', 1, '2024-10-03 14:24:03', NULL),
(47, 30, 'asd', 'asd', 'private', '', '', 0, '2024-10-21 12:01:38', '\"Sexual Harassment\"'),
(48, 30, 'a', 'a', 'private', '', '', 0, '2024-10-21 16:30:30', '\"\"'),
(49, 32, 'sexual', 'harrassment', 'private', '', '', 0, '2024-10-22 14:11:56', '\"Sexual Harassment\"'),
(50, 32, 'Sexual Harassment', ', Domestic Abuse', 'private', '', '', 0, '2024-10-22 14:12:21', '\"Sexual Harassment, Domestic Abuse\"'),
(51, 32, 'Gender Allahu', 'Gender Allahu', 'private', '', '', 0, '2024-10-23 07:47:38', '\"Gender Related\"');

-- --------------------------------------------------------

--
-- Table structure for table `followers`
--

CREATE TABLE `followers` (
  `userID` int(11) NOT NULL,
  `followedUserID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `followers`
--

INSERT INTO `followers` (`userID`, `followedUserID`) VALUES
(30, 31),
(30, 32),
(32, 30);

-- --------------------------------------------------------

--
-- Table structure for table `gadify_actions`
--

CREATE TABLE `gadify_actions` (
  `gadifyID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `entryID` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `action_taken` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gadify_actions`
--

INSERT INTO `gadify_actions` (`gadifyID`, `userID`, `entryID`, `created_at`, `action_taken`) VALUES
(34, 32, 12, '2024-10-18 15:18:08', NULL),
(54, 30, 10, '2024-10-21 11:56:02', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `gender_based_crime_reports`
--

CREATE TABLE `gender_based_crime_reports` (
  `reportID` int(11) NOT NULL,
  `victimName` varchar(255) NOT NULL,
  `perpetratorName` varchar(255) NOT NULL,
  `contactInfo` varchar(255) NOT NULL,
  `gender` enum('male','female','non-binary','prefer-not-to-say') NOT NULL,
  `incidentDescription` text NOT NULL,
  `location` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `witnesses` varchar(255) DEFAULT NULL,
  `supportingDocuments` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gender_based_crime_reports`
--

INSERT INTO `gender_based_crime_reports` (`reportID`, `victimName`, `perpetratorName`, `contactInfo`, `gender`, `incidentDescription`, `location`, `date`, `time`, `witnesses`, `supportingDocuments`, `created_at`) VALUES
(1, 'asd', 'asd', 'asd', '', 'asd', 'asd', '2024-10-01', '10:33:00', 'asd', NULL, '2024-10-22 13:36:55');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `messageID` int(11) NOT NULL,
  `senderID` int(11) NOT NULL,
  `recipientID` int(11) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`messageID`, `senderID`, `recipientID`, `message`, `created_at`) VALUES
(90, 32, 29, 'ASD', '2024-10-15 14:38:27'),
(91, 30, 29, 'a', '2024-10-17 14:03:32');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `notificationID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `actorID` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `entryID` int(11) DEFAULT NULL,
  `type` enum('gadify','follow','unfollow','comment') NOT NULL,
  `timestamp` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_profiles`
--

CREATE TABLE `user_profiles` (
  `profileID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `bio` text DEFAULT NULL,
  `alias` varchar(50) DEFAULT NULL,
  `followersCount` int(11) DEFAULT 0,
  `followingCount` int(11) DEFAULT 0,
  `profile_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_profiles`
--

INSERT INTO `user_profiles` (`profileID`, `userID`, `bio`, `alias`, `followersCount`, `followingCount`, `profile_image`) VALUES
(15, 29, 'Hello', 'Secret', 2, 0, '/uploads/1727721817777.jpg'),
(16, 30, 'Alla', 'asd', 1, 2, '/uploads/1727718033919.png'),
(17, 31, NULL, 'dsa', 3, 0, '/uploads/1727721852196.jpg'),
(18, 32, 'bat ka andito?', 'Allahu', 2, 1, '/uploads/1728401653995.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user_table`
--

CREATE TABLE `user_table` (
  `userID` int(11) NOT NULL,
  `isAdmin` int(10) NOT NULL,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `cvsuEmail` varchar(100) NOT NULL,
  `studentNumber` int(9) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_table`
--

INSERT INTO `user_table` (`userID`, `isAdmin`, `firstName`, `lastName`, `cvsuEmail`, `studentNumber`, `username`, `password`, `created_at`) VALUES
(29, 1, 'John Victor', 'Silva', 'johnvictor.silva@yahoo.com', 202110583, 'Jambik', '$2a$10$GNhK5TgLEA0sR9hlb6uAgOG.HY0.w.r.4bS9Z96dzPoAsHs1FMhyG', '2024-09-30 17:14:36'),
(30, 0, 'John Kenneth', 'Tan', 'johnkenneth.tan@yahoo.com', 1234567890, 'Dave', '$2a$10$YhIZgS.KpDiNV14dF0sPwuynVu/U/ob.jpbQvZMMU.5Ay3mIo6472', '2024-09-30 17:15:28'),
(31, 0, 'John Victoru', 'ASD', 'stephanie@gmail.com', 2147483647, 'Vic', '$2a$10$UCP2K1MtvYhAiHE3qXiNaueL5PCE3IUZjLqwTLVOR/6K5YUH5qoHq', '2024-09-30 17:16:16'),
(32, 0, 'Jem Eraseo Mari', 'Llanto', 'jemmari.llanto@cvsu.edu.ph', 2147483647, 'Jem', '$2a$10$55uYzb8r6HUM6r1zDcKTlOmVIK3pK4pQd4G.S4/jTGX19FYt.tHRG', '2024-10-03 14:03:06');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`commentID`),
  ADD KEY `userID` (`userID`),
  ADD KEY `entryID` (`entryID`),
  ADD KEY `replyCommentID` (`replyCommentID`);

--
-- Indexes for table `diary_entries`
--
ALTER TABLE `diary_entries`
  ADD PRIMARY KEY (`entryID`);

--
-- Indexes for table `followers`
--
ALTER TABLE `followers`
  ADD PRIMARY KEY (`userID`,`followedUserID`),
  ADD KEY `followedUserID` (`followedUserID`);

--
-- Indexes for table `gadify_actions`
--
ALTER TABLE `gadify_actions`
  ADD PRIMARY KEY (`gadifyID`),
  ADD KEY `userID` (`userID`),
  ADD KEY `entryID` (`entryID`);

--
-- Indexes for table `gender_based_crime_reports`
--
ALTER TABLE `gender_based_crime_reports`
  ADD PRIMARY KEY (`reportID`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`messageID`),
  ADD KEY `senderID` (`senderID`),
  ADD KEY `recipientID` (`recipientID`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`notificationID`),
  ADD KEY `userID` (`userID`),
  ADD KEY `actorID` (`actorID`);

--
-- Indexes for table `user_profiles`
--
ALTER TABLE `user_profiles`
  ADD PRIMARY KEY (`profileID`),
  ADD KEY `userID` (`userID`);

--
-- Indexes for table `user_table`
--
ALTER TABLE `user_table`
  ADD PRIMARY KEY (`userID`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `commentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=93;

--
-- AUTO_INCREMENT for table `diary_entries`
--
ALTER TABLE `diary_entries`
  MODIFY `entryID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `gadify_actions`
--
ALTER TABLE `gadify_actions`
  MODIFY `gadifyID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `gender_based_crime_reports`
--
ALTER TABLE `gender_based_crime_reports`
  MODIFY `reportID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `messageID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=92;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `notificationID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `user_profiles`
--
ALTER TABLE `user_profiles`
  MODIFY `profileID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `user_table`
--
ALTER TABLE `user_table`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `user_table` (`userID`),
  ADD CONSTRAINT `comments_ibfk_2` FOREIGN KEY (`entryID`) REFERENCES `diary_entries` (`entryID`),
  ADD CONSTRAINT `comments_ibfk_3` FOREIGN KEY (`replyCommentID`) REFERENCES `comments` (`commentID`) ON DELETE CASCADE;

--
-- Constraints for table `followers`
--
ALTER TABLE `followers`
  ADD CONSTRAINT `followers_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `user_table` (`userID`),
  ADD CONSTRAINT `followers_ibfk_2` FOREIGN KEY (`followedUserID`) REFERENCES `user_table` (`userID`);

--
-- Constraints for table `gadify_actions`
--
ALTER TABLE `gadify_actions`
  ADD CONSTRAINT `gadify_actions_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `user_table` (`userID`) ON DELETE CASCADE,
  ADD CONSTRAINT `gadify_actions_ibfk_2` FOREIGN KEY (`entryID`) REFERENCES `diary_entries` (`entryID`) ON DELETE CASCADE;

--
-- Constraints for table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`senderID`) REFERENCES `user_table` (`userID`),
  ADD CONSTRAINT `messages_ibfk_2` FOREIGN KEY (`recipientID`) REFERENCES `user_table` (`userID`);

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `user_table` (`userID`),
  ADD CONSTRAINT `notifications_ibfk_2` FOREIGN KEY (`actorID`) REFERENCES `user_table` (`userID`);

--
-- Constraints for table `user_profiles`
--
ALTER TABLE `user_profiles`
  ADD CONSTRAINT `user_profiles_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `user_table` (`userID`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
