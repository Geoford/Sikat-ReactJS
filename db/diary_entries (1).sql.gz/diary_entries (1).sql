-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 12, 2024 at 07:46 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sikat-ediary`
--

-- --------------------------------------------------------

--
-- Table structure for table `diary_entries`
--

CREATE TABLE `diary_entries` (
  `entryID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `visibility` enum('public','private') NOT NULL,
  `anonimity` enum('private','public') NOT NULL,
  `diary_image` varchar(255) DEFAULT NULL,
  `gadifyCount` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `subjects` text DEFAULT NULL,
  `containsAlarmingWords` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `diary_entries`
--

INSERT INTO `diary_entries` (`entryID`, `userID`, `title`, `description`, `visibility`, `anonimity`, `diary_image`, `gadifyCount`, `created_at`, `subjects`, `containsAlarmingWords`) VALUES
(55, 30, 'Domestic', 'Abuse', 'public', '', '/uploads/1729670985596.png', 1, '2024-10-23 08:09:45', '\"Domestic Abuse\"', 0),
(57, 31, 'Sexual', 'Harassment', 'public', 'public', '/uploads/1729671217900.gif', 2, '2024-10-23 08:13:38', '\"Sexual Harassment\"', 0),
(118, 29, '54 Years of Cavite State University - CCAT!', '54 Years of Cavite State University - CCAT!\r\nCelebrate the CvSU Values Center - Truth, Excellence, and Service - as we mark our 54th anniversary! With a theme of \"Pagkakaisa Para sa Patuloy na Pag-Angat ng Sistema ng Kalidad sa Pamamahala ng Edukasyon!\"\r\nJoin us for a special celebration on August 7th and 8th, 2024, with all teachers and staff! Two days of joyful service!\r\nBe part of our first Medical Mission, starting at 8 am on August 7th, 2024, at CvSU-CCAT Covered Court 2. Doctors, nurses, and medical staff from Municipality of Rosario, Rotary Club of CEP, Integrated Philippine Association of Optometrists-Cavite Chapter, JNRAL Family Corporation Hospital, and the CvSU-CCAT Medical Unit will offer free medical and dental services, along with medicines and vitamins.\r\nThis event is open to all teachers, employees, their families, retired staff, concessionaires, midyear students, and registered residents of CvSU-CCAT Road.\r\nCome and take care of your health for a great and brilliant life and service!', 'public', 'public', '/uploads/1731247093740.jpg', 0, '2024-11-10 13:58:13', NULL, 0),
(119, 29, '𝐀𝐓𝐓𝐄𝐍𝐓𝐈𝐎𝐍 𝐓𝐎 𝐎𝐔𝐑 𝐒𝐓𝐔𝐃𝐄𝐍𝐓 𝐑𝐄𝐒𝐄𝐀𝐑𝐂𝐇𝐄𝐑𝐒!', '𝐀𝐓𝐓𝐄𝐍𝐓𝐈𝐎𝐍 𝐓𝐎 𝐎𝐔𝐑 𝐒𝐓𝐔𝐃𝐄𝐍𝐓 𝐑𝐄𝐒𝐄𝐀𝐑𝐂𝐇𝐄𝐑𝐒!\r\nWe would like to announce this collaborative project of CvSU CCAT - Research and Extension Unit and CvSU - CCAT Gender and Development as part of the celebration of Womens Month this coming March 2024.\r\n𝐆𝐀𝐃 - 𝐑𝐞𝐬𝐩𝐨𝐧𝐬𝐢𝐯𝐞 𝐑𝐞𝐬𝐞𝐚𝐫𝐜𝐡 𝐁𝐨𝐨𝐭𝐜𝐚𝐦𝐩 𝐨𝐧 𝐌𝐚𝐫𝐜𝐡 𝟏𝟐-𝟏𝟒, 𝟐𝟎𝟐𝟒.\r\nSee details below or you may contact your respective unit research coordinators for more information.\r\nPlease be guided accordingly. \r\nWe are looking forward to your participation, see you!', 'public', 'public', '/uploads/1731247143566.jpg', 0, '2024-11-10 13:59:03', NULL, 0),
(120, 29, 'I AM A WOMAN, OF COURSE.... ', 'I AM A WOMAN, OF COURSE.... \r\nLet\'s talk what it means to be a woman as we begin National Women\'s Month. Let\'s honor Juanas\' amazing strength by breaking stereotypes.', 'public', 'public', '/uploads/1731247209009.jpg', 0, '2024-11-10 14:00:09', NULL, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `diary_entries`
--
ALTER TABLE `diary_entries`
  ADD PRIMARY KEY (`entryID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `diary_entries`
--
ALTER TABLE `diary_entries`
  MODIFY `entryID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=149;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
